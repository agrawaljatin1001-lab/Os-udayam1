const state = { token: localStorage.getItem('udyogos_token') || '', user: null, factory: null, platformFactories: [], platformUsers: [], products: [], machines: [], users: [], adminUsers: [], production: [], quality: [], downtime: [], tasks: [], inventory: [], inventoryMovements: [], maintenance: [], productivity: [], toastTimer: null };
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const localISODate = (date = new Date()) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
const todayISO = () => localISODate();
const escapeHTML = (value = '') => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const number = value => new Intl.NumberFormat('en-IN').format(Number(value || 0));
const dateLabel = value => value ? new Date(`${String(value).slice(0,10)}T00:00:00`).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}) : '—';
const dateTimeLabel = value => value ? new Date(value.endsWith('Z') ? value : `${value}Z`).toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}) : '—';
const productName = id => state.products.find(p => p.id === Number(id))?.name || 'Unlinked product';
const machineName = id => state.machines.find(m => m.id === Number(id))?.name || 'Unassigned machine';
const userName = id => state.users.find(u => u.id === Number(id))?.full_name || 'Unassigned';

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  if (options.body && !(options.body instanceof URLSearchParams) && !(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';
  const response = await fetch(path, { ...options, headers });
  if (response.status === 401 && path !== '/api/auth/login') logout(false);
  if (!response.ok) {
    let detail = `Request failed (${response.status})`;
    try { const payload = await response.json(); detail = Array.isArray(payload.detail) ? payload.detail.map(x => x.msg).join(', ') : (payload.detail || detail); } catch {}
    throw new Error(detail);
  }
  if (response.status === 204) return null;
  const type = response.headers.get('content-type') || '';
  return type.includes('application/json') ? response.json() : response.text();
}

function showToast(message) {
  const toast = $('#toast'); toast.textContent = message; toast.classList.add('show');
  clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
}
function setFeedback(id, message, success = false) {
  const el = $(`#${id}`); if (!el) return;
  el.textContent = message; el.className = `form-feedback${success ? ' success' : ''}`;
}
function setLoading(button, loading, label = 'Saving…') {
  if (!button) return;
  if (loading) { button.dataset.original = button.textContent; button.disabled = true; button.textContent = label; }
  else { button.disabled = false; button.textContent = button.dataset.original || button.textContent; }
}
function roleLabel(role) { return ({platform_admin:'Platform administrator',admin:'Business administrator',manager:'Manager',supervisor:'Supervisor',operator:'Operator'})[role] || role; }

async function startApp() {
  $('#loginScreen').classList.add('hidden'); $('#appShell').classList.remove('hidden');
  try {
    const user = await api('/api/auth/me');
    state.user = user;
    $('#userName').textContent = user.full_name; $('#userRole').textContent = roleLabel(user.role);
    $('#userAvatar').textContent = user.full_name.split(' ').map(x => x[0]).slice(0,2).join('').toUpperCase();
    const isPlatformAdmin = user.role === 'platform_admin';
    $('#platformNav').classList.toggle('hidden', !isPlatformAdmin);
    $$('[data-tenant-nav]').forEach(button => button.classList.toggle('hidden', isPlatformAdmin));
    $('#workspaceLabel').textContent = isPlatformAdmin ? 'PLATFORM' : 'WORKSPACE';
    $('#navLabel').textContent = isPlatformAdmin ? 'ADMINISTRATION' : 'OPERATIONS';
    $('#sidebarFactory').textContent = isPlatformAdmin ? 'UdyogOS Platform' : 'Loading workspace…';
    $('#sidebarCity').textContent = isPlatformAdmin ? 'All businesses' : '';
    $('#workspaceStatus').textContent = isPlatformAdmin ? 'Platform console' : 'Business workspace';
    $('#helpCard').classList.toggle('hidden', isPlatformAdmin);
    $('#todayLabel').textContent = new Date().toLocaleDateString('en-IN',{weekday:'short',day:'2-digit',month:'short',year:'numeric'});
    if (isPlatformAdmin) {
      state.factory = null;
      openView('platform');
      await loadPlatformConsole();
      return;
    }
    const factory = await api('/api/factory');
    state.factory = factory;
    $('#welcomeName').textContent = user.full_name.split(' ')[0];
    $('#sidebarFactory').textContent = factory.name; $('#sidebarCity').textContent = factory.city || 'Factory workspace';
    const businessForm = $('#businessForm');
    businessForm.elements.name.value = factory.name;
    businessForm.elements.business_email.value = factory.business_email;
    businessForm.elements.city.value = factory.city || '';
    businessForm.elements.timezone.value = factory.timezone;
    $$('.date-today').forEach(input => input.value = todayISO());
    $('#dashboardTo').value = todayISO();
    const from = new Date(); from.setDate(from.getDate() - 6); $('#dashboardFrom').value = localISODate(from);
    const canManageMasterData = ['admin','manager'].includes(user.role);
    $('#productForm').classList.toggle('hidden', !canManageMasterData);
    $('#machineForm').classList.toggle('hidden', !canManageMasterData);
    $('#teamNav').classList.toggle('hidden', user.role !== 'admin');
    $('#userFormPanel').classList.toggle('hidden', user.role !== 'admin');
    $('#businessProfilePanel').classList.toggle('hidden', user.role !== 'admin');
    $('#qualityForm').closest('.form-panel').classList.toggle('hidden', user.role === 'operator');
    $('#taskForm').closest('.form-panel').classList.toggle('hidden', user.role === 'operator');
    $$('.inventory-write').forEach(panel => panel.classList.toggle('hidden', !['admin','manager','supervisor'].includes(user.role)));
    $$('.maintenance-write').forEach(panel => panel.classList.toggle('hidden', !['admin','manager','supervisor'].includes(user.role)));
    openView('dashboard');
    await loadReferenceData();
    await loadEverything();
  } catch (error) {
    showToast(error.message || 'Unable to load workspace');
  }
}

function logout(showMessage = true) {
  localStorage.removeItem('udyogos_token'); state.token = ''; state.user = null;
  state.factory = null; state.platformFactories = []; state.platformUsers = [];
  state.products = []; state.machines = []; state.users = []; state.adminUsers = [];
  state.production = []; state.quality = []; state.downtime = []; state.tasks = [];
  state.inventory = []; state.inventoryMovements = []; state.maintenance = []; state.productivity = [];
  $('#appShell').classList.add('hidden'); $('#loginScreen').classList.remove('hidden');
  $('#platformNav').classList.add('hidden'); $$('[data-tenant-nav]').forEach(button => button.classList.remove('hidden'));
  $('#signupForm').classList.add('hidden'); $('#loginForm').classList.remove('hidden'); $('.login-form-panel').classList.remove('signup-mode');
  $('#loginPassword').value = ''; $('#signupForm').reset();
  if (showMessage) showToast('You have signed out.');
}

async function loadPlatformConsole() {
  const [summary, factories, users] = await Promise.all([api('/api/platform/dashboard'), api('/api/platform/factories'), api('/api/platform/users')]);
  state.platformFactories = factories;
  state.platformUsers = users;
  $('#platformBusinessCount').textContent = number(summary.businesses);
  $('#platformActiveCount').textContent = number(summary.active_businesses);
  $('#platformSuspendedCount').textContent = `${number(summary.suspended_businesses)} suspended`;
  $('#platformUserCount').textContent = number(summary.users);
  $('#platformActiveUserCount').textContent = `${number(summary.active_users)} active accounts`;
  $('#platformUsersCount').textContent = String(users.length);
  renderPlatformFactories(); renderPlatformUsers();
}

function renderPlatformFactories() {
  const root = $('#platformFactoryList');
  if (!state.platformFactories.length) {
    root.innerHTML = '<div class="table-empty">No businesses have registered yet.</div>';
    return;
  }
  root.innerHTML = state.platformFactories.map(factory => `<article class="platform-factory-card"><form class="platform-edit-form" data-platform-factory="${factory.id}"><div class="platform-factory-heading"><div><strong>${escapeHTML(factory.name)}</strong><small>${number(factory.user_count)} user accounts · ${escapeHTML(factory.city || 'City not set')}</small></div><span class="status-chip ${factory.is_active ? 'running' : 'down'}">${factory.is_active ? 'Active' : 'Suspended'}</span></div><div class="form-row"><label>Business name<input name="name" value="${escapeHTML(factory.name)}" required minlength="2" maxlength="160" /></label><label>Business email<input name="business_email" type="email" value="${escapeHTML(factory.business_email)}" required /></label></div><div class="form-row"><label>City<input name="city" value="${escapeHTML(factory.city || '')}" maxlength="100" /></label><label>Time zone<input name="timezone" value="${escapeHTML(factory.timezone)}" required maxlength="80" /></label></div><label class="team-active-toggle"><input name="is_active" type="checkbox" ${factory.is_active ? 'checked' : ''} /> Business can sign in</label><button class="btn btn-secondary" type="submit">Save business</button><small class="team-feedback" role="status"></small></form></article>`).join('');
}

function renderPlatformUsers() {
  const root = $('#platformUserList');
  if (!state.platformUsers.length) {
    root.innerHTML = '<div class="table-empty">No business user accounts have registered.</div>';
    return;
  }
  const roles = ['admin','manager','supervisor','operator'];
  root.innerHTML = state.platformUsers.map(account => `<article class="platform-user-card"><div class="platform-user-heading"><div><strong>${escapeHTML(account.full_name)} · @${escapeHTML(account.username)}</strong><small>${escapeHTML(account.business_name)} · ${escapeHTML(account.email)}</small></div><span class="status-chip ${account.is_active ? 'running' : 'down'}">${account.is_active ? 'Active' : 'Inactive'}</span></div><form class="platform-user-edit-form" data-platform-user="${account.id}"><div class="form-row"><label>Full name<input name="full_name" value="${escapeHTML(account.full_name)}" required minlength="2" maxlength="140" /></label><label>Email<input name="email" type="email" value="${escapeHTML(account.email)}" required /></label></div><div class="form-row"><label>Username<input name="username" value="${escapeHTML(account.username)}" required minlength="3" maxlength="80" pattern="[A-Za-z0-9._-]+" /></label><label>Business role<select name="role">${roles.map(role => `<option value="${role}" ${account.role === role ? 'selected' : ''}>${escapeHTML(roleLabel(role))}</option>`).join('')}</select></label></div><label class="team-active-toggle"><input name="is_active" type="checkbox" ${account.is_active ? 'checked' : ''} /> Account can sign in</label><button class="btn btn-secondary" type="submit">Save account</button><small class="team-feedback" role="status"></small></form><form class="platform-user-reset-form" data-platform-password-reset="${account.id}"><label>Set a new password<input name="password" type="password" minlength="12" maxlength="128" required autocomplete="new-password" /></label><button class="btn btn-secondary" type="submit">Reset password</button><small class="team-feedback" role="status"></small></form></article>`).join('');
}

$('#platformCreateForm').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget, button = $('button[type="submit"]', form);
  setFeedback('platformCreateFeedback', ''); setLoading(button, true, 'Creating workspace…');
  try {
    await api('/api/platform/factories', { method:'POST', body:JSON.stringify(Object.fromEntries(new FormData(form).entries())) });
    form.reset(); form.elements.timezone.value = 'Asia/Kolkata';
    setFeedback('platformCreateFeedback', 'Business workspace created.', true);
    await loadPlatformConsole();
  } catch (error) { setFeedback('platformCreateFeedback', error.message); }
  finally { setLoading(button, false); }
});

document.addEventListener('submit', async event => {
  const form = event.target.closest('[data-platform-user]');
  if (!form) return;
  event.preventDefault();
  const button = $('button[type="submit"]', form), feedback = $('.team-feedback', form);
  const userId = Number(form.dataset.platformUser);
  const data = Object.fromEntries(new FormData(form).entries());
  data.is_active = form.elements.is_active.checked;
  setLoading(button, true, 'Saving…');
  try {
    await api(`/api/platform/users/${userId}`, { method:'PATCH', body:JSON.stringify(data) });
    await loadPlatformConsole(); showToast('Business user account updated.');
  } catch (error) { if (feedback) feedback.textContent = error.message; }
  finally { setLoading(button, false); }
});

document.addEventListener('submit', async event => {
  const form = event.target.closest('[data-platform-password-reset]');
  if (!form) return;
  event.preventDefault();
  const button = $('button[type="submit"]', form), feedback = $('.team-feedback', form);
  const userId = Number(form.dataset.platformPasswordReset);
  const password = new FormData(form).get('password');
  setLoading(button, true, 'Resetting…');
  try {
    await api(`/api/platform/users/${userId}/reset-password`, { method:'POST', body:JSON.stringify({password}) });
    form.reset(); if (feedback) feedback.textContent = 'Password reset. Share it privately.';
  } catch (error) { if (feedback) feedback.textContent = error.message; }
  finally { setLoading(button, false); }
});

document.addEventListener('submit', async event => {
  const form = event.target.closest('[data-platform-factory]');
  if (!form) return;
  event.preventDefault();
  const button = $('button[type="submit"]', form);
  const feedback = $('.team-feedback', form);
  const factoryId = Number(form.dataset.platformFactory);
  const data = Object.fromEntries(new FormData(form).entries());
  data.is_active = form.elements.is_active.checked;
  setLoading(button, true, 'Saving…');
  try {
    await api(`/api/platform/factories/${factoryId}`, { method:'PATCH', body:JSON.stringify(data) });
    await loadPlatformConsole();
    showToast('Business workspace updated.');
  } catch (error) { if (feedback) feedback.textContent = error.message; }
  finally { setLoading(button, false); }
});
$('#refreshPlatform').addEventListener('click', () => loadPlatformConsole().then(() => showToast('Business list refreshed.')).catch(error => showToast(error.message)));

$('#showSignup').addEventListener('click', () => { $('#loginForm').classList.add('hidden'); $('#signupForm').classList.remove('hidden'); $('.login-form-panel').classList.add('signup-mode'); $('#signupForm [name="business_name"]').focus(); });
$('#showLogin').addEventListener('click', () => { $('#signupForm').classList.add('hidden'); $('#loginForm').classList.remove('hidden'); $('.login-form-panel').classList.remove('signup-mode'); $('#loginEmail').focus(); });

$('#loginForm').addEventListener('submit', async event => {
  event.preventDefault(); $('#loginError').textContent = '';
  const button = $('button[type="submit"]', event.currentTarget); setLoading(button, true, 'Signing in…');
  try {
    const params = new URLSearchParams(); params.set('username', $('#loginEmail').value.trim()); params.set('password', $('#loginPassword').value);
    const result = await api('/api/auth/login', { method:'POST', body:params });
    state.token = result.access_token; localStorage.setItem('udyogos_token', state.token);
    $('#loginPassword').value = '';
    await startApp();
  } catch (error) { $('#loginError').textContent = error.message; }
  finally { setLoading(button, false); }
});
$('#signupForm').addEventListener('submit', async event => {
  event.preventDefault(); $('#signupError').textContent = '';
  const form = event.currentTarget, button = $('button[type="submit"]', form);
  setLoading(button, true, 'Creating workspace…');
  try {
    const payload = Object.fromEntries(new FormData(form).entries());
    const result = await api('/api/auth/register', { method:'POST', body:JSON.stringify(payload) });
    state.token = result.access_token; localStorage.setItem('udyogos_token', state.token);
    form.reset(); form.elements.timezone.value = 'Asia/Kolkata';
    await startApp();
  } catch (error) { $('#signupError').textContent = error.message; }
  finally { setLoading(button, false); }
});
$('#logoutButton').addEventListener('click', () => logout());

async function loadReferenceData() {
  const requests = [api('/api/products'), api('/api/machines'), api('/api/users')];
  if (state.user?.role === 'admin') requests.push(api('/api/admin/users'));
  const [products, machines, users, adminUsers = []] = await Promise.all(requests);
  state.products = products; state.machines = machines; state.users = users; state.adminUsers = adminUsers;
  populateSelect($('#productionProduct'), products, 'Choose a product', p => `${p.name} (${p.sku || p.unit})`);
  populateSelect($('#qualityProduct'), products, 'Choose a product', p => `${p.name} (${p.sku || p.unit})`);
  populateSelect($('#downtimeMachine'), machines, 'Choose machine (optional)', m => `${m.name} · ${m.code || m.production_line}`, true);
  populateSelect($('#downtimeAssignee'), users, 'Unassigned', u => `${u.full_name} · ${roleLabel(u.role)}`, true);
  populateSelect($('#taskAssignee'), users, 'Unassigned', u => `${u.full_name} · ${roleLabel(u.role)}`, true);
  populateSelect($('#maintenanceMachine'), machines, 'Choose a machine', m => `${m.name} · ${m.code || m.production_line}`);
  populateSelect($('#maintenanceAssignee'), users, 'Unassigned', u => `${u.full_name} · ${roleLabel(u.role)}`, true);
  renderAssets(); renderMachineStatus(); renderTeam();
}
function renderTeam() {
  const isAdmin = state.user?.role === 'admin';
  const users = isAdmin ? state.adminUsers : state.users;
  const teamHeadings = $$('#view-team .panel-heading h2');
  const teamDescriptions = $$('#view-team .panel-heading .muted');
  if (teamHeadings[1]) teamHeadings[1].textContent = isAdmin ? 'All user accounts' : 'My team';
  if (teamDescriptions[1]) teamDescriptions[1].textContent = isAdmin ? 'Manage names, email, roles, sign-in access, and passwords.' : 'People with active access to this factory.';
  $('#userCount').textContent = String(users.length);
  if (!isAdmin) {
    $('#teamList').innerHTML = users.length ? users.map(u => `<div class="asset-item"><span class="asset-symbol">♙</span><div class="row-main"><strong>${escapeHTML(u.full_name)}</strong><small>@${escapeHTML(u.username)} · ${escapeHTML(u.email)} · ${escapeHTML(roleLabel(u.role))}</small></div></div>`).join('') : '<div class="table-empty">No team accounts yet.</div>';
    return;
  }
  const roleOptions = ['admin','manager','supervisor','operator'];
  $('#teamList').innerHTML = users.length ? users.map(u => `<article class="team-admin-card"><div class="team-admin-heading"><strong>${escapeHTML(u.full_name)} · @${escapeHTML(u.username)}</strong><span class="status-chip ${u.is_active ? 'running' : 'down'}">${u.is_active ? 'Active' : 'Inactive'}</span></div><form class="team-edit-form" data-team-edit="${u.id}"><label>Full name<input name="full_name" value="${escapeHTML(u.full_name)}" required minlength="2" /></label><label>Email address<input name="email" type="email" value="${escapeHTML(u.email)}" required /></label><label>Username<input name="username" value="${escapeHTML(u.username)}" required minlength="3" maxlength="80" pattern="[A-Za-z0-9._-]+" /></label><label>Role<select name="role">${roleOptions.map(role => `<option value="${role}" ${u.role === role ? 'selected' : ''}>${escapeHTML(roleLabel(role))}</option>`).join('')}</select></label><label class="team-active-toggle"><input name="is_active" type="checkbox" ${u.is_active ? 'checked' : ''} /> Account can sign in</label><button class="btn btn-secondary" type="submit">Save account details</button><small class="team-feedback" id="teamFeedback${u.id}" role="status"></small></form><form class="team-reset-form" data-password-reset="${u.id}"><label>Set a new password<input name="password" type="password" minlength="12" maxlength="128" required autocomplete="new-password" /></label><button class="btn btn-secondary" type="submit">Reset password</button><small class="team-feedback" id="passwordFeedback${u.id}" role="status"></small></form></article>`).join('') : '<div class="table-empty">No team accounts yet.</div>';
}
function populateSelect(select, items, placeholder, label, optional = false) {
  if (!select) return;
  select.innerHTML = `<option value="">${escapeHTML(placeholder)}</option>` + items.map(item => `<option value="${item.id}">${escapeHTML(label(item))}</option>`).join('');
  if (!optional && items.length) select.value = String(items[0].id);
}

async function loadEverything() {
  await Promise.all([loadDashboard(), loadProduction(), loadQuality(), loadDowntime(), loadTasks(), loadInventory(), loadMaintenance(), loadProductivity(), loadInsights()]);
}
async function loadDashboard() {
  const from = $('#dashboardFrom').value || undefined, to = $('#dashboardTo').value || undefined;
  const query = new URLSearchParams(); if (from) query.set('from_date', from); if (to) query.set('to_date', to);
  const data = await api(`/api/dashboard?${query.toString()}`);
  $('#dashboardFreshness').textContent = `Updated ${new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}`;
  $('#kpiActual').textContent = number(data.production.actual);
  $('#kpiProductionNote').textContent = `Target ${number(data.production.target)} units`;
  $('#kpiAchievement').textContent = `${data.production.achievement_percent}% achieved`;
  $('#productionProgress').style.width = `${Math.min(100, data.production.achievement_percent)}%`;
  $('#kpiRejection').textContent = `${data.quality.rejection_percent}%`;
  $('#kpiQualityNote').textContent = `${number(data.quality.rejected)} rejected units`;
  $('#kpiInspected').textContent = `${number(data.quality.inspected)} inspected`;
  $('#qualityProgress').style.width = `${Math.min(100, data.quality.rejection_percent * 10)}%`;
  const hours = Math.floor(data.downtime.minutes / 60), mins = data.downtime.minutes % 60;
  $('#kpiDowntime').textContent = hours ? `${hours}h ${mins}m` : `${mins}m`;
  $('#kpiOpenEvents').textContent = `${data.downtime.open_events} open`;
  $('#kpiTasks').textContent = number(data.tasks.open); $('#kpiTotalTasks').textContent = `${data.tasks.total} total`;
  renderProductionChart(data.recent_production);
}
function renderProductionChart(days) {
  const root = $('#productionChart');
  if (!days.length) { root.innerHTML = '<div class="table-empty">No production records in this period.</div>'; return; }
  const max = Math.max(1, ...days.flatMap(d => [d.target, d.actual]));
  root.innerHTML = days.map(d => {
    const a = Math.max(2, d.actual / max * 100), t = Math.max(2, d.target / max * 100);
    const day = new Date(`${d.date}T00:00:00`).toLocaleDateString('en-IN',{day:'2-digit',month:'short'});
    return `<div class="chart-column" title="${escapeHTML(day)} · Actual ${number(d.actual)} / Target ${number(d.target)}"><div class="chart-bar target" style="height:${t}%"></div><div class="chart-bar actual" style="height:${a}%"></div><span class="chart-day">${escapeHTML(day)}</span></div>`;
  }).join('');
}
async function loadProduction() {
  state.production = await api('/api/production');
  $('#productionCount').textContent = state.production.length;
  $('#productionRows').innerHTML = state.production.length ? state.production.slice(0,100).map(r => {
    const pct = r.target_quantity ? (r.actual_quantity / r.target_quantity * 100).toFixed(1) : '0.0';
    return `<tr><td>${dateLabel(r.production_date)}</td><td>${escapeHTML(productName(r.product_id))}</td><td>${escapeHTML(r.shift)} / ${escapeHTML(r.production_line)}</td><td>${number(r.actual_quantity)}</td><td>${number(r.target_quantity)}</td><td><span class="status-chip ${Number(pct)>=100?'done':Number(pct)<90?'open':'in_progress'}">${pct}%</span></td></tr>`;
  }).join('') : emptyRow(6, 'No production records yet.');
}
async function loadQuality() {
  state.quality = await api('/api/quality'); $('#qualityCount').textContent = state.quality.length;
  $('#qualityRows').innerHTML = state.quality.length ? state.quality.slice(0,100).map(r => {
    const pct = r.inspected_quantity ? (r.rejected_quantity / r.inspected_quantity * 100).toFixed(2) : '0.00';
    return `<tr><td>${dateLabel(r.inspection_date)}</td><td>${escapeHTML(productName(r.product_id))}</td><td>${escapeHTML(r.batch_number || '—')}</td><td>${number(r.inspected_quantity)}</td><td>${number(r.rejected_quantity)}</td><td><span class="status-chip ${Number(pct)>=3?'open':'done'}">${pct}%</span></td><td>${escapeHTML(r.defect_type)}</td></tr>`;
  }).join('') : emptyRow(7, 'No quality inspections recorded yet.');
}
async function loadDowntime() {
  state.downtime = await api('/api/downtime'); $('#downtimeCount').textContent = state.downtime.length;
  $('#downtimeRows').innerHTML = state.downtime.length ? state.downtime.map(r => `<tr><td>${escapeHTML(machineName(r.machine_id))}</td><td>${dateTimeLabel(r.started_at)}</td><td>${formatDuration(r.downtime_minutes)}</td><td title="${escapeHTML(r.reason)}">${escapeHTML(r.reason.length>48?r.reason.slice(0,45)+'…':r.reason)}</td><td><span class="status-chip ${r.status}">${escapeHTML(r.status)}</span></td><td>${r.status==='open'?`<button class="table-action" data-resolve-downtime="${r.id}">Resolve</button>`:'—'}</td></tr>`).join('') : emptyRow(6, 'No machine downtime logged.');
  renderMachineStatus();
}
async function loadTasks() {
  state.tasks = await api('/api/tasks'); $('#taskCount').textContent = state.tasks.length;
  $('#taskRows').innerHTML = state.tasks.length ? state.tasks.map(t => {
    const canUpdate = state.user.role !== 'operator' || [null, state.user.id].includes(t.assigned_to);
    return `<tr><td title="${escapeHTML(t.description)}">${escapeHTML(t.title)}</td><td><span class="priority-dot ${t.priority}"></span> ${escapeHTML(t.priority)}</td><td>${escapeHTML(userName(t.assigned_to))}</td><td>${dateLabel(t.due_date)}</td><td><span class="status-chip ${t.status}">${escapeHTML(t.status.replace('_',' '))}</span></td><td>${canUpdate ? `<select class="task-status-select" data-task-status="${t.id}" aria-label="Update task status"><option value="open" ${t.status==='open'?'selected':''}>Open</option><option value="in_progress" ${t.status==='in_progress'?'selected':''}>In progress</option><option value="blocked" ${t.status==='blocked'?'selected':''}>Blocked</option><option value="done" ${t.status==='done'?'selected':''}>Done</option></select>` : '—'}</td></tr>`;
  }).join('') : emptyRow(6, 'No actions have been created.');
  renderDashboardTasks();
}
function formatQuantity(value) { return new Intl.NumberFormat('en-IN',{maximumFractionDigits:3}).format(Number(value || 0)); }
async function loadInventory() {
  const [items, movements] = await Promise.all([api('/api/inventory'), api('/api/inventory/movements')]);
  state.inventory = items; state.inventoryMovements = movements;
  populateSelect($('#inventoryItem'), items, 'Choose a stock item', item => `${item.sku} · ${item.name}`);
  const editSelect = $('#inventoryEditItem'), previousEditId = editSelect.value;
  populateSelect(editSelect, items, 'Choose a stock item', item => `${item.sku} · ${item.name}`);
  if (items.some(item => String(item.id) === previousEditId)) editSelect.value = previousEditId;
  fillInventoryEditForm();
  $('#inventoryCount').textContent = String(items.length);
  $('#inventoryRows').innerHTML = items.length ? items.map(item => {
    const low = Number(item.reorder_level) > 0 && Number(item.quantity_on_hand) <= Number(item.reorder_level);
    return `<tr><td>${escapeHTML(item.sku)}</td><td>${escapeHTML(item.name)}</td><td>${escapeHTML(item.category)}</td><td>${formatQuantity(item.quantity_on_hand)} ${escapeHTML(item.unit)}</td><td>${formatQuantity(item.reorder_level)} ${escapeHTML(item.unit)}</td><td>${escapeHTML(item.location || '—')}</td><td><span class="status-chip ${low?'down':'running'}">${low?'Reorder':'In stock'}</span></td></tr>`;
  }).join('') : emptyRow(7, 'No stock items have been added.');
  $('#inventoryMovementRows').innerHTML = movements.length ? movements.slice(0,100).map(movement => {
    const item = items.find(candidate => candidate.id === movement.item_id);
    return `<tr><td>${dateTimeLabel(movement.created_at)}</td><td>${escapeHTML(item?.name || `Item #${movement.item_id}`)}</td><td><span class="status-chip ${movement.movement_type==='out'?'open':'running'}">${escapeHTML(movement.movement_type)}</span></td><td>${formatQuantity(movement.quantity)}</td><td>${formatQuantity(movement.resulting_quantity)}</td><td>${escapeHTML(movement.reason)}</td></tr>`;
  }).join('') : emptyRow(6, 'No stock movements recorded yet.');
}
function fillInventoryEditForm() {
  const form = $('#inventoryEditForm');
  if (!form) return;
  const item = state.inventory.find(candidate => candidate.id === Number(form.elements.item_id.value));
  if (!item) { form.elements.name.value = ''; form.elements.category.value = ''; form.elements.unit.value = ''; form.elements.reorder_level.value = ''; form.elements.location.value = ''; return; }
  form.elements.name.value = item.name;
  form.elements.category.value = item.category;
  form.elements.unit.value = item.unit;
  form.elements.reorder_level.value = Number(item.reorder_level);
  form.elements.location.value = item.location || '';
}
$('#inventoryEditItem').addEventListener('change', fillInventoryEditForm);
async function loadMaintenance() {
  state.maintenance = await api('/api/maintenance');
  $('#maintenanceCount').textContent = String(state.maintenance.length);
  $('#maintenanceRows').innerHTML = state.maintenance.length ? state.maintenance.map(order => {
    const canUpdate = ['admin','manager','supervisor'].includes(state.user.role) || order.assigned_to === state.user.id;
    const statusCell = canUpdate && !['completed','cancelled'].includes(order.status)
      ? `<div class="maintenance-update"><select data-maintenance-status="${order.id}" aria-label="Update ${escapeHTML(order.title)} status"><option value="planned" ${order.status==='planned'?'selected':''}>Planned</option><option value="in_progress" ${order.status==='in_progress'?'selected':''}>In progress</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option></select><input data-maintenance-notes="${order.id}" maxlength="3000" value="${escapeHTML(order.completion_notes || '')}" placeholder="Work / completion note" aria-label="Work note for ${escapeHTML(order.title)}" /></div>`
      : `<span class="status-chip ${order.status==='completed'?'done':order.status==='cancelled'?'open':'in_progress'}">${escapeHTML(order.status.replace('_',' '))}</span>`;
    return `<tr><td>${dateLabel(order.due_date)}</td><td>${escapeHTML(machineName(order.machine_id))}</td><td title="${escapeHTML(order.description)}"><strong>${escapeHTML(order.title)}</strong><small class="table-subline">${escapeHTML(order.description || '')}</small></td><td>${escapeHTML(order.maintenance_type)} · ${escapeHTML(order.priority)}</td><td>${escapeHTML(userName(order.assigned_to))}</td><td>${statusCell}</td></tr>`;
  }).join('') : emptyRow(6, 'No maintenance work orders are scheduled.');
}
async function loadProductivity() {
  const summary = await api('/api/productivity'); state.productivity = summary.people;
  $('#productivityPeriod').textContent = `${dateLabel(summary.range.from_date)} – ${dateLabel(summary.range.to_date)} · ${summary.definition}`;
  $('#productivityCount').textContent = String(summary.people.length);
  $('#productivityRows').innerHTML = summary.people.length ? summary.people.map(person => `<tr><td><strong>${escapeHTML(person.full_name)}</strong><small class="table-subline">${escapeHTML(roleLabel(person.role))}</small></td><td>${number(person.tasks_assigned)} / ${number(person.tasks_done)}</td><td>${number(person.production_entries)}</td><td>${number(person.units_recorded)}</td><td>${number(person.quality_inspections)}</td><td>${number(person.downtime_reports)}</td><td>${number(person.maintenance_completed)}</td></tr>`).join('') : emptyRow(7, 'No recorded work activity in this period.');
}
async function loadInsights() {
  const data = await api('/api/insights');
  const items = data.items || [];
  $('#dashboardInsights').innerHTML = items.slice(0,3).map(signalHTML).join('');
  $('#insightCards').innerHTML = items.map(item => `<article class="insight-card"><span class="signal-mark ${escapeHTML(item.level)}"></span><h3>${escapeHTML(item.title)}</h3><p>${escapeHTML(item.detail)}</p></article>`).join('');
}
function signalHTML(item) { return `<div class="signal-item"><i class="signal-mark ${escapeHTML(item.level)}"></i><div><strong>${escapeHTML(item.title)}</strong><p>${escapeHTML(item.detail)}</p></div></div>`; }
function renderDashboardTasks() {
  const pending = state.tasks.filter(t => t.status !== 'done').slice(0,4);
  $('#dashboardTasks').innerHTML = pending.length ? pending.map(t => `<div class="compact-row"><i class="priority-dot ${escapeHTML(t.priority)}"></i><div class="row-main"><strong>${escapeHTML(t.title)}</strong><small>${escapeHTML(userName(t.assigned_to))} · Due ${dateLabel(t.due_date)}</small></div><span class="status-chip ${escapeHTML(t.status)}">${escapeHTML(t.status.replace('_',' '))}</span></div>`).join('') : '<div class="table-empty">No open actions. Good work.</div>';
}
function renderMachineStatus() {
  const root = $('#dashboardMachines'); if (!root) return;
  root.innerHTML = state.machines.length ? state.machines.slice(0,5).map(m => {
    const tone = m.status === 'down' ? 'down' : m.status === 'maintenance' ? 'maintenance' : 'running';
    const label = m.status === 'down' ? 'Down' : m.status === 'maintenance' ? 'Maintenance' : 'Running';
    return `<div class="machine-row"><i class="machine-indicator ${tone}"></i><div class="row-main"><strong>${escapeHTML(m.name)}</strong><small>${escapeHTML(m.code || m.production_line)}</small></div><span class="status-chip ${tone}">${label}</span></div>`;
  }).join('') : '<div class="table-empty">Add machines to see their status.</div>';
}
function renderAssets() {
  $('#productList').innerHTML = state.products.length ? state.products.map(p => `<div class="asset-item"><span class="asset-symbol">▤</span><div class="row-main"><strong>${escapeHTML(p.name)}</strong><small>${escapeHTML(p.sku || 'No SKU')} · ${escapeHTML(p.unit)}</small></div><span class="status-chip running">Active</span></div>`).join('') : '<div class="table-empty">No products added.</div>';
  $('#machineList').innerHTML = state.machines.length ? state.machines.map(m => {
    const tone = m.status === 'down' ? 'down' : m.status === 'maintenance' ? 'maintenance' : 'running';
    return `<div class="asset-item"><span class="asset-symbol">⚙</span><div class="row-main"><strong>${escapeHTML(m.name)}</strong><small>${escapeHTML(m.code || 'No code')} · ${escapeHTML(m.production_line)}</small></div><span class="status-chip ${tone}">${escapeHTML(m.status)}</span></div>`;
  }).join('') : '<div class="table-empty">No machines added.</div>';
}
function emptyRow(cols, message) { return `<tr><td colspan="${cols}" class="table-empty">${escapeHTML(message)}</td></tr>`; }
function formatDuration(minutes) { const n = Number(minutes || 0); return n >= 60 ? `${Math.floor(n/60)}h ${n%60}m` : `${n}m`; }

function openView(view) {
  $$('.view-section').forEach(s => s.classList.toggle('active', s.id === `view-${view}`));
  $$('.nav-item').forEach(b => { const active = b.dataset.view === view; b.classList.toggle('active', active); if (active) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
  $('#breadcrumbCurrent').textContent = ({dashboard:'Overview',production:'Production',quality:'Quality control',downtime:'Machine downtime',inventory:'Inventory',maintenance:'Machine maintenance',tasks:'Tasks & actions',productivity:'Team activity',assets:'Products & machines',team:'Admin panel',insights:'AI insights',platform:'Platform administration'})[view] || 'Overview';
  const heading = $(`#view-${view} h1`); if (heading) { heading.tabIndex = -1; heading.focus({ preventScroll: true }); }
  closeSidebar();
  if (view === 'insights') loadInsights().catch(e => showToast(e.message));
  if (view === 'assets') loadReferenceData().catch(e => showToast(e.message));
  if (view === 'inventory') loadInventory().catch(e => showToast(e.message));
  if (view === 'maintenance') loadMaintenance().catch(e => showToast(e.message));
  if (view === 'productivity') loadProductivity().catch(e => showToast(e.message));
}
$$('.nav-item').forEach(button => button.addEventListener('click', () => openView(button.dataset.view)));
$$('[data-open-view]').forEach(button => button.addEventListener('click', () => openView(button.dataset.openView)));
$('#applyDashboardDates').addEventListener('click', () => loadDashboard().catch(e => showToast(e.message)));
$('#refreshInsights').addEventListener('click', () => loadInsights().then(() => showToast('Insights refreshed.')).catch(e => showToast(e.message)));
$('#refreshProductivity').addEventListener('click', () => loadProductivity().then(() => showToast('Team activity refreshed.')).catch(e => showToast(e.message)));

function bindCreateForm(formId, endpoint, feedbackId, afterSave) {
  const form = $(`#${formId}`);
  form.addEventListener('submit', async event => {
    event.preventDefault(); const button = $('button[type="submit"]', form) || $('button:not([type])', form);
    setFeedback(feedbackId, ''); setLoading(button, true);
    const data = Object.fromEntries(new FormData(form).entries());
    for (const key of ['product_id','machine_id','item_id','assigned_to']) if (key in data) data[key] = data[key] ? Number(data[key]) : null;
    for (const key of ['target_quantity','actual_quantity','inspected_quantity','rejected_quantity','quantity_on_hand','reorder_level','quantity']) if (key in data) data[key] = Number(data[key]);
    for (const key of ['due_date']) if (key in data && !data[key]) data[key] = null;
    try {
      await api(endpoint, {method:'POST', body:JSON.stringify(data)});
      form.reset(); $$('.date-today', form).forEach(input => input.value = todayISO());
      if (formId === 'productionForm') { $('#productionProduct').value = state.products[0]?.id || ''; }
      if (formId === 'qualityForm') { $('#qualityProduct').value = state.products[0]?.id || ''; }
      setFeedback(feedbackId, 'Saved successfully.', true); showToast('Record saved.');
      if (afterSave) await afterSave();
    } catch (error) { setFeedback(feedbackId, error.message); }
    finally { setLoading(button, false); }
  });
}
bindCreateForm('productionForm','/api/production','productionFeedback',async()=>{await Promise.all([loadProduction(),loadDashboard()]);});
bindCreateForm('qualityForm','/api/quality','qualityFeedback',async()=>{await Promise.all([loadQuality(),loadDashboard(),loadInsights()]);});
bindCreateForm('downtimeForm','/api/downtime','downtimeFeedback',async()=>{await Promise.all([loadDowntime(),loadDashboard(),loadInsights()]);});
bindCreateForm('taskForm','/api/tasks','taskFeedback',async()=>{await Promise.all([loadTasks(),loadDashboard(),loadInsights()]);});
bindCreateForm('inventoryItemForm','/api/inventory','inventoryItemFeedback',async()=>{await Promise.all([loadInventory(),loadInsights()]);});
bindCreateForm('inventoryMovementForm','/api/inventory/movements','inventoryMovementFeedback',async()=>{await Promise.all([loadInventory(),loadInsights()]);});
bindCreateForm('maintenanceForm','/api/maintenance','maintenanceFeedback',async()=>{await Promise.all([loadMaintenance(),loadInsights()]);});
$('#inventoryEditForm').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget, button = $('button[type="submit"]', form), itemId = Number(form.elements.item_id.value);
  const data = Object.fromEntries(new FormData(form).entries());
  delete data.item_id; data.reorder_level = Number(data.reorder_level);
  setFeedback('inventoryEditFeedback', ''); setLoading(button, true, 'Saving…');
  try {
    await api(`/api/inventory/${itemId}`, { method:'PATCH', body:JSON.stringify(data) });
    setFeedback('inventoryEditFeedback', 'Item details saved.', true);
    await Promise.all([loadInventory(),loadInsights()]);
  } catch (error) { setFeedback('inventoryEditFeedback', error.message); }
  finally { setLoading(button, false); }
});

$('#productForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = event.currentTarget, data = Object.fromEntries(new FormData(form).entries());
  try { await api('/api/products',{method:'POST',body:JSON.stringify(data)}); form.reset(); form.elements.unit.value='pcs'; await loadReferenceData(); showToast('Product added.'); }
  catch(error){showToast(error.message);}
});
$('#machineForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = event.currentTarget, data = Object.fromEntries(new FormData(form).entries());
  try { await api('/api/machines',{method:'POST',body:JSON.stringify(data)}); form.reset(); await loadReferenceData(); showToast('Machine added.'); }
  catch(error){showToast(error.message);}
});

$('#userForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = event.currentTarget, button = $('button[type="submit"]', form);
  setFeedback('userFeedback', ''); setLoading(button, true, 'Creating account…');
  try {
    const data = Object.fromEntries(new FormData(form).entries());
    await api('/api/users', { method:'POST', body:JSON.stringify(data) });
    form.reset(); setFeedback('userFeedback', 'Account created. Share the initial password privately.', true);
    await loadReferenceData();
  } catch (error) { setFeedback('userFeedback', error.message); }
  finally { setLoading(button, false); }
});

$('#businessForm').addEventListener('submit', async event => {
  event.preventDefault(); const form = event.currentTarget, button = $('button[type="submit"]', form);
  setFeedback('businessFeedback', ''); setLoading(button, true, 'Saving profile…');
  try {
    const updated = await api('/api/factory', { method:'PATCH', body:JSON.stringify(Object.fromEntries(new FormData(form).entries())) });
    state.factory = updated; $('#sidebarFactory').textContent = updated.name; $('#sidebarCity').textContent = updated.city || 'Factory workspace';
    setFeedback('businessFeedback', 'Business profile saved.', true);
  } catch (error) { setFeedback('businessFeedback', error.message); }
  finally { setLoading(button, false); }
});

document.addEventListener('submit', async event => {
  const editForm = event.target.closest('[data-team-edit]');
  if (editForm) {
    event.preventDefault();
    const button = $('button[type="submit"]', editForm), userId = Number(editForm.dataset.teamEdit);
    const data = Object.fromEntries(new FormData(editForm).entries());
    data.is_active = editForm.elements.is_active.checked;
    setLoading(button, true, 'Saving…');
    try {
      await api(`/api/users/${userId}`, { method:'PATCH', body:JSON.stringify(data) });
      await loadReferenceData();
      if (userId === state.user.id) {
        await startApp();
        if (state.user.role !== 'admin') openView('dashboard');
      }
      showToast('Team account updated.');
    } catch (error) {
      const feedback = $('.team-feedback', editForm); if (feedback) feedback.textContent = error.message;
    } finally { setLoading(button, false); }
    return;
  }

  const resetForm = event.target.closest('[data-password-reset]');
  if (!resetForm) return;
  event.preventDefault();
  const button = $('button[type="submit"]', resetForm), userId = Number(resetForm.dataset.passwordReset);
  const password = new FormData(resetForm).get('password');
  setLoading(button, true, 'Resetting…');
  try {
    await api(`/api/users/${userId}/reset-password`, { method:'POST', body:JSON.stringify({password}) });
    resetForm.reset(); showToast('Password reset. Share the new password privately.');
  } catch (error) {
    const feedback = $('.team-feedback', resetForm); if (feedback) feedback.textContent = error.message;
  } finally { setLoading(button, false); }
});

document.addEventListener('click', async event => {
  const resolveButton = event.target.closest('[data-resolve-downtime]');
  if (resolveButton) {
    resolveButton.disabled = true;
    try { await api(`/api/downtime/${resolveButton.dataset.resolveDowntime}/resolve`,{method:'PATCH'}); await Promise.all([loadDowntime(),loadReferenceData(),loadDashboard(),loadInsights()]); showToast('Downtime event resolved.'); }
    catch(error){showToast(error.message);resolveButton.disabled=false;}
  }
  const exportButton = event.target.closest('[data-export]');
  if (exportButton) {
    try {
      const response = await fetch(`/api/reports/export.csv?kind=${encodeURIComponent(exportButton.dataset.export)}`,{headers:{Authorization:`Bearer ${state.token}`}});
      if (!response.ok) throw new Error('Unable to export this report.');
      const blob = await response.blob(), url = URL.createObjectURL(blob), link = document.createElement('a');
      link.href=url; link.download=`udyogos-${exportButton.dataset.export}.csv`; document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); showToast('CSV export ready.');
    } catch(error){showToast(error.message);}
  }
});
document.addEventListener('change', async event => {
  const maintenanceSelect = event.target.closest('[data-maintenance-status]');
  if (maintenanceSelect) {
    const orderId = Number(maintenanceSelect.dataset.maintenanceStatus);
    const noteField = $(`[data-maintenance-notes="${orderId}"]`);
    maintenanceSelect.disabled = true;
    try {
      await api(`/api/maintenance/${orderId}`, { method:'PATCH', body:JSON.stringify({status:maintenanceSelect.value, completion_notes:noteField?.value || ''}) });
      await Promise.all([loadMaintenance(),loadReferenceData(),loadProductivity(),loadInsights()]);
      showToast('Maintenance order updated.');
    } catch (error) { showToast(error.message); await loadMaintenance(); }
    finally { maintenanceSelect.disabled = false; }
    return;
  }
  const select = event.target.closest('[data-task-status]'); if (!select) return;
  select.disabled = true;
  try { await api(`/api/tasks/${select.dataset.taskStatus}`,{method:'PATCH',body:JSON.stringify({status:select.value})}); await Promise.all([loadTasks(),loadDashboard(),loadInsights()]); showToast('Task status updated.'); }
  catch(error){showToast(error.message);}
  finally{select.disabled=false;}
});

function closeSidebar(){ $('#sidebar').classList.remove('open'); $('#sidebarScrim').classList.remove('show'); $('#menuToggle').setAttribute('aria-expanded','false'); }
$('#menuToggle').addEventListener('click',()=>{$('#sidebar').classList.add('open');$('#sidebarScrim').classList.add('show');$('#menuToggle').setAttribute('aria-expanded','true');$('#closeSidebar').focus();});
$('#closeSidebar').addEventListener('click',closeSidebar); $('#sidebarScrim').addEventListener('click',closeSidebar);
document.addEventListener('keydown', event => { if (event.key === 'Escape' && $('#sidebar').classList.contains('open')) { closeSidebar(); $('#menuToggle').focus(); } });

$('#voiceButton').addEventListener('click', () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) { $('#voiceHint').textContent = 'Voice recognition is not supported in this browser. Type the issue instead.'; return; }
  const recognition = new SpeechRecognition(); recognition.lang = $('#voiceLanguage').value; recognition.interimResults = false; recognition.maxAlternatives = 1;
  $('#voiceHint').textContent = recognition.lang === 'hi-IN' ? 'Listening… Speak in Hindi.' : 'Listening… Speak in English.';
  recognition.onresult = event => { const text = event.results[0][0].transcript; $('#downtimeReason').value = `${$('#downtimeReason').value} ${text}`.trim(); $('#voiceHint').textContent = 'Voice note added. Review the text before submitting.'; };
  recognition.onerror = () => { $('#voiceHint').textContent = 'Voice input could not be captured. Please type the issue.'; };
  recognition.onend = () => { if ($('#voiceHint').textContent.startsWith('Listening…')) $('#voiceHint').textContent = 'Voice input ended. Review the captured text.'; };
  try { recognition.start(); }
  catch { $('#voiceHint').textContent = 'Voice input could not start. Please type the issue.'; }
});

if (state.token) startApp().catch(() => logout(false));
