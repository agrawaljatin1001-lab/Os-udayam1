import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../frontend/index.html', import.meta.url), 'utf8');
const js = readFileSync(new URL('../frontend/app.js', import.meta.url), 'utf8');
const foundIds = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
const ids = new Set(foundIds);
const duplicateIds = foundIds.filter((id, index) => foundIds.indexOf(id) !== index);
const selectedIds = [...js.matchAll(/\$\('#([A-Za-z][\w-]*)'\)/g)].map(match => match[1]);
const missingIds = [...new Set(selectedIds)].filter(id => !ids.has(id));
const views = [...html.matchAll(/data-view="([^"]+)"/g)].map(match => match[1]);
const missingViews = [...new Set(views)].filter(view => !ids.has(`view-${view}`));

if (duplicateIds.length || missingIds.length || missingViews.length) {
  if (duplicateIds.length) console.error(`Duplicate HTML IDs: ${[...new Set(duplicateIds)].join(', ')}`);
  if (missingIds.length) console.error(`JavaScript references missing HTML IDs: ${missingIds.join(', ')}`);
  if (missingViews.length) console.error(`Navigation views are missing: ${missingViews.join(', ')}`);
  process.exitCode = 1;
} else {
  console.log(`Frontend consistency check passed (${ids.size} unique IDs, ${new Set(views).size} navigation views).`);
}
