from datetime import datetime, timedelta, timezone
from decimal import Decimal
from zoneinfo import ZoneInfo
from sqlalchemy.orm import Session
from .models import Factory, User, Product, Machine, ProductionEntry, QualityInspection, DowntimeEvent, Task, InventoryItem, InventoryMovement, MaintenanceOrder
from .security import hash_password


def seed_demo_data(db: Session) -> None:
    if not db.query(User).filter(User.role == "platform_admin").first():
        db.add(User(
            factory_id=None, full_name="UdyogOS Platform Admin", username="platform.admin",
            email="platform@udyogos.demo", password_hash=hash_password("Demo@12345"), role="platform_admin",
        ))
        db.flush()
    if db.query(Factory).first():
        db.commit()
        return
    factory = Factory(name="Aarav Components Pvt. Ltd.", business_email="contact@aarav-components.demo", city="Pithampur, Madhya Pradesh", timezone="Asia/Kolkata")
    db.add(factory)
    db.flush()
    admin = User(factory_id=factory.id, full_name="Factory Owner", username="demo_owner", email="admin@udyogos.demo", password_hash=hash_password("Demo@12345"), role="admin")
    manager = User(factory_id=factory.id, full_name="Production Manager", username="demo_manager", email="manager@udyogos.demo", password_hash=hash_password("Demo@12345"), role="manager")
    supervisor = User(factory_id=factory.id, full_name="Shift Supervisor", username="demo_supervisor", email="supervisor@udyogos.demo", password_hash=hash_password("Demo@12345"), role="supervisor")
    operator = User(factory_id=factory.id, full_name="Line Operator", username="demo_operator", email="operator@udyogos.demo", password_hash=hash_password("Demo@12345"), role="operator")
    db.add_all([admin, manager, supervisor, operator])
    db.flush()

    products = [
        Product(factory_id=factory.id, name="Precision Bracket", sku="PB-100", unit="pcs"),
        Product(factory_id=factory.id, name="Mounting Plate", sku="MP-210", unit="pcs"),
        Product(factory_id=factory.id, name="Housing Assembly", sku="HA-330", unit="pcs"),
    ]
    machines = [
        Machine(factory_id=factory.id, name="CNC Machine 01", code="CNC-01", production_line="Line 1"),
        Machine(factory_id=factory.id, name="Hydraulic Press 02", code="PRS-02", production_line="Line 2"),
        Machine(factory_id=factory.id, name="Assembly Station 03", code="ASM-03", production_line="Line 3"),
    ]
    db.add_all(products + machines)
    db.flush()
    inventory = [
        InventoryItem(factory_id=factory.id, sku="RM-STEEL-01", name="Mild steel sheet", category="Raw material", unit="kg", quantity_on_hand=Decimal("620"), reorder_level=Decimal("150"), location="Store A"),
        InventoryItem(factory_id=factory.id, sku="MRO-OIL-02", name="Hydraulic oil", category="Maintenance supply", unit="L", quantity_on_hand=Decimal("18"), reorder_level=Decimal("30"), location="Tool crib"),
    ]
    db.add_all(inventory)
    db.flush()
    db.add_all([
        InventoryMovement(factory_id=factory.id, item_id=item.id, movement_type="opening", quantity=item.quantity_on_hand, previous_quantity=Decimal("0"), resulting_quantity=item.quantity_on_hand, reason="Opening stock", created_by=admin.id)
        for item in inventory
    ])
    db.add(MaintenanceOrder(
        factory_id=factory.id, machine_id=machines[0].id, title="Inspect spindle and coolant system",
        description="Check vibration, coolant flow and record the service result.", maintenance_type="preventive",
        priority="medium", status="planned", due_date=datetime.now(timezone.utc).date() + timedelta(days=2),
        assigned_to=manager.id, created_by=admin.id,
    ))
    today = datetime.now(timezone.utc).astimezone(ZoneInfo(factory.timezone)).date()
    for offset in range(6, -1, -1):
        dt = today - timedelta(days=offset)
        for index, product in enumerate(products):
            target = 420 + (index * 80)
            actual = target - ((offset + index * 3) % 7) * 12
            db.add(ProductionEntry(factory_id=factory.id, product_id=product.id, production_date=dt, shift="A" if index % 2 == 0 else "B", production_line=f"Line {index + 1}", target_quantity=target, actual_quantity=actual, notes="Demo production data", created_by=manager.id))
        db.add(QualityInspection(factory_id=factory.id, product_id=products[offset % 3].id, inspection_date=dt, batch_number=f"B-{dt.strftime('%m%d')}", inspected_quantity=400, rejected_quantity=8 + (offset % 4) * 3, defect_type=["Dimensional variance", "Surface scratch", "Burr"] [offset % 3], notes="Demo inspection data", created_by=supervisor.id))
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
    db.add(DowntimeEvent(factory_id=factory.id, machine_id=machines[0].id, started_at=now_utc - timedelta(hours=5), ended_at=now_utc - timedelta(hours=4, minutes=20), downtime_minutes=40, reason="Coolant flow sensor fault", status="resolved", assigned_to=manager.id, created_by=supervisor.id))
    db.add(DowntimeEvent(factory_id=factory.id, machine_id=machines[1].id, started_at=now_utc - timedelta(minutes=22), downtime_minutes=22, reason="Hydraulic pressure below operating range", status="open", assigned_to=manager.id, created_by=operator.id))
    db.add_all([
        Task(factory_id=factory.id, title="Inspect coolant flow sensor", description="Verify sensor readings and record the corrective action.", priority="high", status="in_progress", due_date=today, assigned_to=manager.id, created_by=supervisor.id),
        Task(factory_id=factory.id, title="Review today's rejection trend", description="Check dimensional variance on Precision Bracket batches.", priority="medium", status="open", due_date=today + timedelta(days=1), assigned_to=supervisor.id, created_by=manager.id),
        Task(factory_id=factory.id, title="Complete press safety checklist", description="Record pre-shift checks for Hydraulic Press 02.", priority="critical", status="open", due_date=today, assigned_to=operator.id, created_by=manager.id),
    ])
    db.commit()
