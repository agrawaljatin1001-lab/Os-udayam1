import re
from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "UdyogOS"
    environment: str = "development"
    secret_key: str = "development-only-secret-do-not-deploy"
    access_token_expire_minutes: int = 720
    database_url: str = "sqlite:///./udyogos.db"
    db_pool_size: int = 5
    db_max_overflow: int = 10
    db_pool_timeout: int = 30
    cors_origins: str = "http://localhost:8000,http://127.0.0.1:8000"
    bootstrap_factory_name: str = ""
    bootstrap_business_email: str = ""
    bootstrap_factory_city: str = ""
    bootstrap_admin_name: str = ""
    bootstrap_admin_username: str = ""
    bootstrap_admin_email: str = ""
    bootstrap_admin_password: str = ""
    platform_admin_name: str = ""
    platform_admin_username: str = ""
    platform_admin_email: str = ""
    platform_admin_password: str = ""
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @model_validator(mode="after")
    def validate_production_settings(self):
        if self.environment.lower() != "production":
            return self
        if len(self.secret_key) < 32 or self.secret_key == "development-only-secret-do-not-deploy":
            raise ValueError("Production requires a unique SECRET_KEY of at least 32 characters")
        if not self.database_url.startswith(("postgresql://", "postgresql+psycopg://")):
            raise ValueError("Production requires PostgreSQL; set DATABASE_URL")
        bootstrap_values = (
            self.bootstrap_factory_name,
            self.bootstrap_business_email,
            self.bootstrap_admin_name,
            self.bootstrap_admin_username,
            self.bootstrap_admin_email,
            self.bootstrap_admin_password,
        )
        if any(bootstrap_values) and not all(bootstrap_values):
            raise ValueError("For a bootstrap workspace, set all BOOTSTRAP_FACTORY_*, BOOTSTRAP_BUSINESS_EMAIL, and BOOTSTRAP_ADMIN_* values")
        if self.bootstrap_admin_password and len(self.bootstrap_admin_password) < 12:
            raise ValueError("BOOTSTRAP_ADMIN_PASSWORD must be at least 12 characters")
        if self.bootstrap_admin_username and not re.fullmatch(r"[A-Za-z0-9._-]{3,80}", self.bootstrap_admin_username.strip()):
            raise ValueError("BOOTSTRAP_ADMIN_USERNAME must be 3-80 letters, numbers, dots, underscores, or hyphens")
        if self.bootstrap_factory_name and not 2 <= len(self.bootstrap_factory_name.strip()) <= 160:
            raise ValueError("BOOTSTRAP_FACTORY_NAME must contain 2-160 characters")
        if self.bootstrap_admin_name and not 2 <= len(self.bootstrap_admin_name.strip()) <= 140:
            raise ValueError("BOOTSTRAP_ADMIN_NAME must contain 2-140 characters")
        platform_values = (self.platform_admin_name, self.platform_admin_username, self.platform_admin_email, self.platform_admin_password)
        if any(platform_values) and not all(platform_values):
            raise ValueError("Set all PLATFORM_ADMIN_* values to bootstrap the platform administrator")
        if not all(platform_values):
            raise ValueError("Production requires PLATFORM_ADMIN_NAME, PLATFORM_ADMIN_USERNAME, PLATFORM_ADMIN_EMAIL, and PLATFORM_ADMIN_PASSWORD for the central website admin")
        if self.platform_admin_password and len(self.platform_admin_password) < 12:
            raise ValueError("PLATFORM_ADMIN_PASSWORD must be at least 12 characters")
        if not 2 <= len(self.platform_admin_name.strip()) <= 140:
            raise ValueError("PLATFORM_ADMIN_NAME must contain 2-140 characters")
        if not re.fullmatch(r"[A-Za-z0-9._-]{3,80}", self.platform_admin_username.strip()):
            raise ValueError("PLATFORM_ADMIN_USERNAME must be 3-80 letters, numbers, dots, underscores, or hyphens")
        if len(self.platform_admin_email.strip()) > 190 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", self.platform_admin_email.strip()):
            raise ValueError("PLATFORM_ADMIN_EMAIL must be a valid email address")
        if self.bootstrap_admin_email and self.bootstrap_admin_email.strip().lower() == self.platform_admin_email.strip().lower():
            raise ValueError("The platform administrator and bootstrap business owner must use different email addresses")
        if self.bootstrap_admin_username and self.bootstrap_admin_username.strip().lower() == self.platform_admin_username.strip().lower():
            raise ValueError("The platform administrator and bootstrap business owner must use different usernames")
        if self.bootstrap_admin_email and (len(self.bootstrap_admin_email.strip()) > 190 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", self.bootstrap_admin_email.strip())):
            raise ValueError("BOOTSTRAP_ADMIN_EMAIL must be a valid email address")
        if self.bootstrap_business_email and (len(self.bootstrap_business_email.strip()) > 190 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", self.bootstrap_business_email.strip())):
            raise ValueError("BOOTSTRAP_BUSINESS_EMAIL must be a valid email address")
        if min(self.db_pool_size, self.db_pool_timeout) < 1 or self.db_max_overflow < 0:
            raise ValueError("Database pool settings must be positive (overflow may be zero)")
        if any(not origin.startswith("https://") for origin in self.allowed_origins):
            raise ValueError("Production CORS_ORIGINS must use HTTPS")
        return self

    @property
    def allowed_origins(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


settings = Settings()
