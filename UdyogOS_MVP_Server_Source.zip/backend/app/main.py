from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from io import StringIO
import csv
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from sqlalchemy import case, func, inspect, or_, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .config import settings
from .database import Base, engine, get_db, SessionLocal
from .deps import get_current_user, require_roles
from .models import Factory, User, Product, Machine, ProductionEntry, QualityInspection, DowntimeEvent, Task, InventoryItem, InventoryMovement, MaintenanceOrder
from .schemas import (
    LoginOut, UserOut, UserAdminOut, PlatformUserOut, UserCreate, UserUpdate, PasswordReset, BusinessRegistration, FactoryOut, FactoryUpdate, PlatformFactoryUpdate, PlatformFactoryOut, ProductCreate, ProductOut, MachineCreate, MachineOut,
    ProductionCreate, ProductionOut, QualityCreate, QualityOut, DowntimeCreate, DowntimeOut,
    TaskCreate, TaskUpdate, TaskOut, InventoryItemCreate, InventoryItemUpdate, InventoryItemOut, InventoryMovementCreate, InventoryMovementOut,
    MaintenanceOrderCreate, MaintenanceOrderUpdate, MaintenanceOrderOut,
)
from .security import create_access_token, hash_password, verify_password
from .seed import seed_demo_data

FRONTEND_DIR = Path(__file__).resolve().parents[2] / "frontend"


def utc_now_naive() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def factory_today(db: Session, user: User) -> date:
    return datetime.now(timezone.utc).astimezone(factory_timezone(db, user)).date()


def factory_timezone(db: Session, user: User):
    timezone_name = db.query(Factory.timezone).filter(Factory.id == user.factory_id).scalar() or "Asia/Kolkata"
    try:
        return ZoneInfo(timezone_name)
    except ZoneInfoNotFoundError:
        return timezone.utc


def migrate_sqlite_nullable_user_factory(db: Session) -> None:
    """Rebuild legacy SQLite users tables so the separate platform admin can have no tenant."""
    columns = inspect(db.connection()).get_columns("users")
    factory_id_column = next(column for column in columns if column["name"] == "factory_id")
    if factory_id_column.get("nullable", True):
        return
    db.commit()
    raw_connection = engine.raw_connection()
    cursor = raw_connection.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys=OFF")
        if cursor.execute("PRAGMA foreign_keys").fetchone()[0] != 0:
            raise RuntimeError("Could not disable SQLite foreign key checks for the users table migration")
        cursor.execute("BEGIN IMMEDIATE")
        cursor.execute("DROP TABLE IF EXISTS users__new")
        cursor.execute("""
            CREATE TABLE users__new (
                id INTEGER NOT NULL PRIMARY KEY,
                factory_id INTEGER,
                full_name VARCHAR(140) NOT NULL,
                username VARCHAR(80) NOT NULL DEFAULT '',
                email VARCHAR(190) NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                role VARCHAR(30) DEFAULT 'operator',
                is_active BOOLEAN DEFAULT 1,
                token_version INTEGER NOT NULL DEFAULT 0,
                created_at DATETIME,
                FOREIGN KEY(factory_id) REFERENCES factories(id)
            )
        """)
        cursor.execute("""
            INSERT INTO users__new (id, factory_id, full_name, username, email, password_hash, role, is_active, token_version, created_at)
            SELECT id, factory_id, full_name, username, email, password_hash, role, is_active, token_version, created_at FROM users
        """)
        cursor.execute("DROP TABLE users")
        cursor.execute("ALTER TABLE users__new RENAME TO users")
        cursor.execute("CREATE UNIQUE INDEX IF NOT EXISTS ix_users_email ON users (email)")
        cursor.execute("CREATE INDEX IF NOT EXISTS ix_users_factory_id ON users (factory_id)")
        raw_connection.commit()
    except Exception:
        raw_connection.rollback()
        raise
    finally:
        cursor.execute("PRAGMA foreign_keys=ON")
        raw_connection.commit()
        cursor.close()
        raw_connection.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    db = SessionLocal()
    try:
        if settings.environment.lower() == "production":
            # Serialize first-run setup if the host starts multiple app replicas together.
            db.execute(text("SELECT pg_advisory_xact_lock(792613825)"))
        Base.metadata.create_all(bind=db.connection())
        user_columns = {column["name"] for column in inspect(db.connection()).get_columns("users")}
        if "token_version" not in user_columns:
            db.execute(text("ALTER TABLE users ADD COLUMN token_version INTEGER NOT NULL DEFAULT 0"))
        if "username" not in user_columns:
            db.execute(text("ALTER TABLE users ADD COLUMN username VARCHAR(80) NOT NULL DEFAULT ''"))
            db.execute(text("UPDATE users SET username = 'user-' || id WHERE username = ''"))
        if settings.environment.lower() == "production":
            factory_id_column = next(column for column in inspect(db.connection()).get_columns("users") if column["name"] == "factory_id")
            if not factory_id_column.get("nullable", True) and db.bind.dialect.name == "postgresql":
                db.execute(text("ALTER TABLE users ALTER COLUMN factory_id DROP NOT NULL"))
        elif db.bind.dialect.name == "sqlite":
            migrate_sqlite_nullable_user_factory(db)
        factory_columns = {column["name"] for column in inspect(db.connection()).get_columns("factories")}
        if "business_email" not in factory_columns:
            db.execute(text("ALTER TABLE factories ADD COLUMN business_email VARCHAR(190) NOT NULL DEFAULT ''"))
            db.execute(text("UPDATE factories SET business_email = 'workspace-' || id || '@migrated.udyogos.invalid' WHERE business_email = ''"))
        if "is_active" not in factory_columns:
            db.execute(text("ALTER TABLE factories ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT TRUE"))
        # SQLAlchemy cannot reliably reflect expression indexes on SQLite, so
        # use the database's idempotent DDL instead of Index.create(checkfirst=True).
        db.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS uq_users_email_ci ON users (lower(email))"))
        db.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS uq_users_username_ci ON users (lower(username))"))
        db.execute(text("CREATE UNIQUE INDEX IF NOT EXISTS uq_factories_business_email_ci ON factories (lower(business_email))"))
        if settings.environment.lower() == "production":
            factory = db.query(Factory).first()
            if not factory and settings.bootstrap_factory_name:
                factory = Factory(
                    name=settings.bootstrap_factory_name.strip(),
                    business_email=settings.bootstrap_business_email.strip().lower(),
                    city=settings.bootstrap_factory_city.strip(),
                    timezone="Asia/Kolkata",
                )
                db.add(factory)
                db.flush()
                db.add(User(
                    factory_id=factory.id,
                    full_name=settings.bootstrap_admin_name.strip(),
                    username=settings.bootstrap_admin_username.strip().lower(),
                    email=settings.bootstrap_admin_email.strip().lower(),
                    password_hash=hash_password(settings.bootstrap_admin_password),
                    role="admin",
                ))
            platform_admin = db.query(User).filter(User.role == "platform_admin").first()
            if not platform_admin and settings.platform_admin_email:
                db.add(User(
                    factory_id=None,
                    full_name=settings.platform_admin_name.strip(),
                    username=settings.platform_admin_username.strip().lower(),
                    email=settings.platform_admin_email.strip().lower(),
                    password_hash=hash_password(settings.platform_admin_password),
                    role="platform_admin",
                ))
            # Commit once so the advisory lock covers both bootstrap accounts.
            db.commit()
        else:
            seed_demo_data(db)
    finally:
        db.close()
    yield


app = FastAPI(title=settings.app_name, version="0.1.0", description="Factory operations MVP for production, quality, downtime and tasks.", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


def scoped(query, model, user: User):
    return query.filter(model.factory_id == user.factory_id)


def parse_range(from_date: date | None, to_date: date | None, today: date | None = None):
    today = today or date.today()
    start = from_date or today - timedelta(days=6)
    end = to_date or today
    if start > end:
        raise HTTPException(status_code=422, detail="from_date must be on or before to_date")
    if (end - start).days > 366:
        raise HTTPException(status_code=422, detail="Date range cannot exceed 367 days")
    return start, end


def validate_product(db: Session, product_id: int | None, factory_id: int):
    if product_id is not None and not db.query(Product).filter(Product.id == product_id, Product.factory_id == factory_id, Product.is_active.is_(True)).first():
        raise HTTPException(status_code=404, detail="Product not found in this factory")


def validate_machine(db: Session, machine_id: int | None, factory_id: int):
    if machine_id is not None and not db.query(Machine).filter(Machine.id == machine_id, Machine.factory_id == factory_id).first():
        raise HTTPException(status_code=404, detail="Machine not found in this factory")


def validate_assignee(db: Session, user_id: int | None, factory_id: int):
    if user_id is not None and not db.query(User).filter(User.id == user_id, User.factory_id == factory_id, User.is_active.is_(True)).first():
        raise HTTPException(status_code=404, detail="Assignee not found in this factory")


def refresh_machine_operational_status(db: Session, machine: Machine) -> None:
    # Sessions disable autoflush; persist pending order/event state before deriving the machine state.
    db.flush()
    has_open_downtime = db.query(DowntimeEvent.id).filter(
        DowntimeEvent.factory_id == machine.factory_id,
        DowntimeEvent.machine_id == machine.id,
        DowntimeEvent.status == "open",
    ).first() is not None
    has_active_maintenance = db.query(MaintenanceOrder.id).filter(
        MaintenanceOrder.factory_id == machine.factory_id,
        MaintenanceOrder.machine_id == machine.id,
        MaintenanceOrder.status == "in_progress",
    ).first() is not None
    if has_open_downtime:
        machine.status = "down"
    elif has_active_maintenance:
        machine.status = "maintenance"
    elif machine.status in {"down", "maintenance"}:
        machine.status = "running"


def create_business_workspace(db: Session, payload: BusinessRegistration):
    if db.query(Factory).filter(func.lower(Factory.business_email) == payload.business_email).first():
        raise HTTPException(status_code=409, detail="A business with this email already exists")
    if db.query(User).filter((func.lower(User.email) == payload.owner_email) | (func.lower(User.username) == payload.username)).first():
        raise HTTPException(status_code=409, detail="That login email or username is already in use")
    factory = Factory(name=payload.business_name, business_email=payload.business_email, city=payload.city, timezone=payload.timezone)
    db.add(factory)
    try:
        db.flush()
        owner = User(
            factory_id=factory.id,
            full_name=payload.owner_name,
            username=payload.username,
            email=payload.owner_email,
            password_hash=hash_password(payload.password),
            role="admin",
        )
        db.add(owner)
        db.commit()
        db.refresh(factory)
        db.refresh(owner)
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="That business email, account email, or username is already in use")
    return factory, owner


@app.get("/api/health")
def health(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ok", "database": "connected", "app": settings.app_name, "version": "0.1.0"}


@app.post("/api/auth/login", response_model=LoginOut)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    identity = form.username.strip().lower()
    user = db.query(User).filter((func.lower(User.email) == identity) | (func.lower(User.username) == identity)).first()
    if not user or not user.is_active or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Incorrect email or password", headers={"WWW-Authenticate": "Bearer"})
    if user.factory_id is not None and not db.query(Factory).filter(Factory.id == user.factory_id, Factory.is_active.is_(True)).first():
        raise HTTPException(status_code=401, detail="This business workspace is inactive", headers={"WWW-Authenticate": "Bearer"})
    token = create_access_token(str(user.id), user.token_version)
    return {"access_token": token, "token_type": "bearer", "user": user}


@app.post("/api/auth/register", response_model=LoginOut, status_code=201)
def register_business(payload: BusinessRegistration, db: Session = Depends(get_db)):
    _, owner = create_business_workspace(db, payload)
    token = create_access_token(str(owner.id), owner.token_version)
    return {"access_token": token, "token_type": "bearer", "user": owner}


@app.get("/api/auth/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user


@app.get("/api/factory", response_model=FactoryOut)
def get_factory(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    factory = db.query(Factory).filter(Factory.id == user.factory_id).first()
    if not factory:
        raise HTTPException(status_code=404, detail="Factory not found")
    return factory


@app.patch("/api/factory", response_model=FactoryOut)
def update_factory(payload: FactoryUpdate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    factory = db.query(Factory).filter(Factory.id == user.factory_id).first()
    if not factory:
        raise HTTPException(status_code=404, detail="Factory not found")
    duplicate = db.query(Factory).filter(func.lower(Factory.business_email) == payload.business_email, Factory.id != factory.id).first()
    if duplicate:
        raise HTTPException(status_code=409, detail="A business with this email already exists")
    factory.name = payload.name
    factory.business_email = payload.business_email
    factory.city = payload.city
    factory.timezone = payload.timezone
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="A business with this email already exists")
    db.refresh(factory)
    return factory


@app.get("/api/platform/dashboard")
def platform_dashboard(db: Session = Depends(get_db), user: User = Depends(require_roles("platform_admin"))):
    total_businesses, active_businesses = db.query(
        func.count(Factory.id),
        func.coalesce(func.sum(case((Factory.is_active.is_(True), 1), else_=0)), 0),
    ).one()
    total_users = db.query(User).filter(User.factory_id.is_not(None)).count()
    active_users = db.query(User).filter(User.factory_id.is_not(None), User.is_active.is_(True)).count()
    return {
        "businesses": int(total_businesses),
        "active_businesses": int(active_businesses),
        "suspended_businesses": int(total_businesses - active_businesses),
        "users": total_users,
        "active_users": active_users,
    }


@app.get("/api/platform/factories", response_model=list[PlatformFactoryOut])
def platform_list_factories(db: Session = Depends(get_db), user: User = Depends(require_roles("platform_admin"))):
    rows = db.query(Factory, func.count(User.id)).outerjoin(User, User.factory_id == Factory.id).group_by(Factory.id).order_by(Factory.created_at.desc(), Factory.id.desc()).all()
    return [{**{key: getattr(factory, key) for key in ("id", "name", "business_email", "city", "timezone", "is_active", "created_at")}, "user_count": count} for factory, count in rows]


@app.post("/api/platform/factories", response_model=PlatformFactoryOut, status_code=201)
def platform_create_factory(payload: BusinessRegistration, db: Session = Depends(get_db), user: User = Depends(require_roles("platform_admin"))):
    factory, _ = create_business_workspace(db, payload)
    return {**{key: getattr(factory, key) for key in ("id", "name", "business_email", "city", "timezone", "is_active", "created_at")}, "user_count": 1}


@app.patch("/api/platform/factories/{factory_id}", response_model=PlatformFactoryOut)
def platform_update_factory(factory_id: int, payload: PlatformFactoryUpdate, db: Session = Depends(get_db), user: User = Depends(require_roles("platform_admin"))):
    factory = db.query(Factory).filter(Factory.id == factory_id).first()
    if not factory:
        raise HTTPException(status_code=404, detail="Business workspace not found")
    if db.query(Factory).filter(func.lower(Factory.business_email) == payload.business_email, Factory.id != factory.id).first():
        raise HTTPException(status_code=409, detail="A business with this email already exists")
    factory.name = payload.name
    factory.business_email = payload.business_email
    factory.city = payload.city
    factory.timezone = payload.timezone
    if factory.is_active != payload.is_active:
        factory.is_active = payload.is_active
        db.query(User).filter(User.factory_id == factory.id).update({User.token_version: User.token_version + 1}, synchronize_session=False)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="A business with this email already exists")
    db.refresh(factory)
    user_count = db.query(User).filter(User.factory_id == factory.id).count()
    return {**{key: getattr(factory, key) for key in ("id", "name", "business_email", "city", "timezone", "is_active", "created_at")}, "user_count": user_count}


@app.get("/api/platform/users", response_model=list[PlatformUserOut])
def platform_list_users(db: Session = Depends(get_db), user: User = Depends(require_roles("platform_admin"))):
    rows = db.query(User, Factory.name).join(Factory, Factory.id == User.factory_id).order_by(Factory.name, User.full_name, User.id).all()
    return [{**{key: getattr(account, key) for key in ("id", "full_name", "email", "username", "role", "factory_id", "is_active", "created_at")}, "business_name": business_name} for account, business_name in rows]


@app.patch("/api/platform/users/{user_id}", response_model=PlatformUserOut)
def platform_update_user(user_id: int, payload: UserUpdate, db: Session = Depends(get_db), user: User = Depends(require_roles("platform_admin"))):
    target = db.query(User).filter(User.id == user_id, User.factory_id.is_not(None)).first()
    if not target:
        raise HTTPException(status_code=404, detail="Business user account not found")
    duplicate = db.query(User).filter(
        User.id != target.id,
        (func.lower(User.email) == payload.email) | (func.lower(User.username) == payload.username),
    ).first()
    if duplicate:
        raise HTTPException(status_code=409, detail="That login email or username is already in use")
    removing_admin = target.role == "admin" and target.is_active and (payload.role != "admin" or not payload.is_active)
    if removing_admin:
        active_admin_ids = db.query(User.id).filter(
            User.factory_id == target.factory_id,
            User.role == "admin",
            User.is_active.is_(True),
        ).order_by(User.id).with_for_update().all()
        if len(active_admin_ids) <= 1:
            raise HTTPException(status_code=409, detail="The business must keep at least one active administrator")
    if target.is_active != payload.is_active:
        target.token_version += 1
    target.full_name = payload.full_name
    target.email = payload.email
    target.username = payload.username
    target.role = payload.role
    target.is_active = payload.is_active
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="That login email or username is already in use")
    db.refresh(target)
    business_name = db.query(Factory.name).filter(Factory.id == target.factory_id).scalar()
    return {**{key: getattr(target, key) for key in ("id", "full_name", "email", "username", "role", "factory_id", "is_active", "created_at")}, "business_name": business_name}


@app.post("/api/platform/users/{user_id}/reset-password")
def platform_reset_user_password(user_id: int, payload: PasswordReset, db: Session = Depends(get_db), user: User = Depends(require_roles("platform_admin"))):
    target = db.query(User).filter(User.id == user_id, User.factory_id.is_not(None)).first()
    if not target:
        raise HTTPException(status_code=404, detail="Business user account not found")
    target.password_hash = hash_password(payload.password)
    target.token_version += 1
    db.commit()
    return {"status": "updated"}


@app.get("/api/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.query(User).filter(User.factory_id == user.factory_id, User.is_active.is_(True)).order_by(User.full_name).all()


@app.post("/api/users", response_model=UserOut, status_code=201)
def create_user(payload: UserCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    if db.query(User).filter((func.lower(User.email) == payload.email) | (func.lower(User.username) == payload.username)).first():
        raise HTTPException(status_code=409, detail="That login email or username is already in use")
    created = User(
        factory_id=user.factory_id,
        full_name=payload.full_name.strip(),
        username=payload.username,
        email=payload.email,
        password_hash=hash_password(payload.password),
        role=payload.role,
    )
    db.add(created)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="That login email or username is already in use")
    db.refresh(created)
    return created


@app.get("/api/admin/users", response_model=list[UserAdminOut])
def admin_list_users(db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    return db.query(User).filter(User.factory_id == user.factory_id).order_by(User.full_name, User.id).all()


@app.patch("/api/users/{user_id}", response_model=UserAdminOut)
def update_user(user_id: int, payload: UserUpdate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    target = db.query(User).filter(User.id == user_id, User.factory_id == user.factory_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="Team account not found")
    duplicate = db.query(User).filter(
        User.id != target.id,
        (func.lower(User.email) == payload.email) | (func.lower(User.username) == payload.username),
    ).first()
    if duplicate:
        raise HTTPException(status_code=409, detail="That login email or username is already in use")
    if target.id == user.id and not payload.is_active:
        raise HTTPException(status_code=409, detail="You cannot deactivate your own account")
    removing_admin = target.role == "admin" and target.is_active and (payload.role != "admin" or not payload.is_active)
    if removing_admin:
        active_admin_ids = db.query(User.id).filter(
            User.factory_id == user.factory_id,
            User.role == "admin",
            User.is_active.is_(True),
        ).order_by(User.id).with_for_update().all()
        if len(active_admin_ids) <= 1:
            raise HTTPException(status_code=409, detail="The factory must keep at least one active administrator")
    if target.is_active != payload.is_active:
        target.token_version += 1
    target.full_name = payload.full_name
    target.email = payload.email
    target.username = payload.username
    target.role = payload.role
    target.is_active = payload.is_active
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="That login email or username is already in use")
    db.refresh(target)
    return target


@app.post("/api/users/{user_id}/reset-password")
def reset_user_password(user_id: int, payload: PasswordReset, db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    target = db.query(User).filter(User.id == user_id, User.factory_id == user.factory_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="Team account not found")
    target.password_hash = hash_password(payload.password)
    target.token_version += 1
    db.commit()
    return {"status": "updated"}


@app.get("/api/products", response_model=list[ProductOut])
def list_products(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return scoped(db.query(Product), Product, user).filter(Product.is_active.is_(True)).order_by(Product.name).all()


@app.post("/api/products", response_model=ProductOut, status_code=201)
def create_product(payload: ProductCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager"))):
    if payload.sku and db.query(Product).filter(Product.factory_id == user.factory_id, func.lower(Product.sku) == payload.sku.lower(), Product.is_active.is_(True)).first():
        raise HTTPException(status_code=409, detail="A product with this SKU already exists in this factory")
    product = Product(factory_id=user.factory_id, **payload.model_dump())
    db.add(product); db.commit(); db.refresh(product)
    return product


@app.get("/api/machines", response_model=list[MachineOut])
def list_machines(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return scoped(db.query(Machine), Machine, user).order_by(Machine.name).all()


@app.post("/api/machines", response_model=MachineOut, status_code=201)
def create_machine(payload: MachineCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager"))):
    if payload.code and db.query(Machine).filter(Machine.factory_id == user.factory_id, func.lower(Machine.code) == payload.code.lower()).first():
        raise HTTPException(status_code=409, detail="A machine with this code already exists in this factory")
    machine = Machine(factory_id=user.factory_id, **payload.model_dump())
    db.add(machine); db.commit(); db.refresh(machine)
    return machine


@app.get("/api/production", response_model=list[ProductionOut])
def list_production(
    from_date: date | None = None, to_date: date | None = None,
    db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    start, end = parse_range(from_date, to_date, factory_today(db, user))
    return scoped(db.query(ProductionEntry), ProductionEntry, user).filter(ProductionEntry.production_date.between(start, end)).order_by(ProductionEntry.production_date.desc(), ProductionEntry.id.desc()).limit(500).all()


@app.post("/api/production", response_model=ProductionOut, status_code=201)
def create_production(payload: ProductionCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager", "supervisor", "operator"))):
    validate_product(db, payload.product_id, user.factory_id)
    entry = ProductionEntry(factory_id=user.factory_id, created_by=user.id, **payload.model_dump())
    db.add(entry); db.commit(); db.refresh(entry)
    return entry


@app.get("/api/quality", response_model=list[QualityOut])
def list_quality(
    from_date: date | None = None, to_date: date | None = None,
    db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    start, end = parse_range(from_date, to_date, factory_today(db, user))
    return scoped(db.query(QualityInspection), QualityInspection, user).filter(QualityInspection.inspection_date.between(start, end)).order_by(QualityInspection.inspection_date.desc(), QualityInspection.id.desc()).limit(500).all()


@app.post("/api/quality", response_model=QualityOut, status_code=201)
def create_quality(payload: QualityCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager", "supervisor"))):
    validate_product(db, payload.product_id, user.factory_id)
    if payload.rejected_quantity > payload.inspected_quantity:
        raise HTTPException(status_code=422, detail="Rejected quantity cannot exceed inspected quantity")
    inspection = QualityInspection(factory_id=user.factory_id, created_by=user.id, **payload.model_dump())
    db.add(inspection); db.commit(); db.refresh(inspection)
    return inspection


@app.get("/api/downtime", response_model=list[DowntimeOut])
def list_downtime(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    events = scoped(db.query(DowntimeEvent), DowntimeEvent, user).order_by(DowntimeEvent.started_at.desc()).limit(300).all()
    now = utc_now_naive()
    for event in events:
        if event.status == "open":
            event.downtime_minutes = max(0, int((now - event.started_at).total_seconds() // 60))
    return events


@app.post("/api/downtime", response_model=DowntimeOut, status_code=201)
def create_downtime(payload: DowntimeCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager", "supervisor", "operator"))):
    validate_machine(db, payload.machine_id, user.factory_id)
    validate_assignee(db, payload.assigned_to, user.factory_id)
    event = DowntimeEvent(factory_id=user.factory_id, created_by=user.id, machine_id=payload.machine_id, reason=payload.reason, assigned_to=payload.assigned_to, started_at=payload.started_at or utc_now_naive(), downtime_minutes=0, status="open")
    db.add(event)
    if payload.machine_id:
        machine = db.query(Machine).filter(Machine.id == payload.machine_id, Machine.factory_id == user.factory_id).first()
        machine.status = "down"
    db.commit(); db.refresh(event)
    return event


@app.patch("/api/downtime/{event_id}/resolve", response_model=DowntimeOut)
def resolve_downtime(event_id: int, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager", "supervisor"))):
    event = db.query(DowntimeEvent).filter(DowntimeEvent.id == event_id, DowntimeEvent.factory_id == user.factory_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Downtime event not found")
    if event.status == "open":
        event.ended_at = utc_now_naive()
        event.downtime_minutes = max(0, int((event.ended_at - event.started_at).total_seconds() // 60))
        event.status = "resolved"
        if event.machine_id:
            open_events = db.query(DowntimeEvent).filter(DowntimeEvent.machine_id == event.machine_id, DowntimeEvent.factory_id == user.factory_id, DowntimeEvent.status == "open", DowntimeEvent.id != event.id).count()
            if open_events == 0:
                machine = db.query(Machine).filter(Machine.id == event.machine_id, Machine.factory_id == user.factory_id).first()
                if machine:
                    refresh_machine_operational_status(db, machine)
    db.commit(); db.refresh(event)
    return event


@app.get("/api/tasks", response_model=list[TaskOut])
def list_tasks(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return scoped(db.query(Task), Task, user).order_by(Task.created_at.desc()).limit(300).all()


@app.post("/api/tasks", response_model=TaskOut, status_code=201)
def create_task(payload: TaskCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager", "supervisor"))):
    validate_assignee(db, payload.assigned_to, user.factory_id)
    task = Task(factory_id=user.factory_id, created_by=user.id, **payload.model_dump())
    db.add(task); db.commit(); db.refresh(task)
    return task


@app.patch("/api/tasks/{task_id}", response_model=TaskOut)
def update_task(task_id: int, payload: TaskUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    task = db.query(Task).filter(Task.id == task_id, Task.factory_id == user.factory_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    updates = {key: value for key, value in payload.model_dump(exclude_unset=True).items() if value is not None or key == "assigned_to"}
    if "assigned_to" in updates:
        validate_assignee(db, updates["assigned_to"], user.factory_id)
    if user.role == "operator":
        if task.assigned_to not in (None, user.id):
            raise HTTPException(status_code=403, detail="You can only update tasks assigned to you")
        if set(updates) - {"status"}:
            raise HTTPException(status_code=403, detail="Operators can only update task status")
    for key, value in updates.items():
        setattr(task, key, value)
    task.updated_at = utc_now_naive()
    db.commit(); db.refresh(task)
    return task


@app.get("/api/inventory", response_model=list[InventoryItemOut])
def list_inventory(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return scoped(db.query(InventoryItem), InventoryItem, user).filter(InventoryItem.is_active.is_(True)).order_by(InventoryItem.name).limit(1000).all()


@app.post("/api/inventory", response_model=InventoryItemOut, status_code=201)
def create_inventory_item(payload: InventoryItemCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager", "supervisor"))):
    if db.query(InventoryItem.id).filter(
        InventoryItem.factory_id == user.factory_id,
        func.lower(InventoryItem.sku) == payload.sku.lower(),
    ).first():
        raise HTTPException(status_code=409, detail="An inventory item with this SKU already exists")
    item = InventoryItem(factory_id=user.factory_id, **payload.model_dump())
    db.add(item)
    try:
        db.flush()
        if item.quantity_on_hand > 0:
            db.add(InventoryMovement(
                factory_id=user.factory_id, item_id=item.id, movement_type="opening",
                quantity=item.quantity_on_hand, previous_quantity=Decimal("0"),
                resulting_quantity=item.quantity_on_hand, reason="Opening stock", created_by=user.id,
            ))
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="An inventory item with this SKU already exists")
    db.refresh(item)
    return item


@app.patch("/api/inventory/{item_id}", response_model=InventoryItemOut)
def update_inventory_item(item_id: int, payload: InventoryItemUpdate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager", "supervisor"))):
    item = db.query(InventoryItem).filter(InventoryItem.id == item_id, InventoryItem.factory_id == user.factory_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    updates = payload.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(status_code=422, detail="Provide at least one inventory field to update")
    for key, value in updates.items():
        if value is not None:
            setattr(item, key, value)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Inventory update conflicts with existing data")
    db.refresh(item)
    return item


@app.get("/api/inventory/movements", response_model=list[InventoryMovementOut])
def list_inventory_movements(item_id: int | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    query = scoped(db.query(InventoryMovement), InventoryMovement, user)
    if item_id is not None:
        query = query.filter(InventoryMovement.item_id == item_id)
    return query.order_by(InventoryMovement.created_at.desc(), InventoryMovement.id.desc()).limit(500).all()


@app.post("/api/inventory/movements", response_model=InventoryMovementOut, status_code=201)
def create_inventory_movement(payload: InventoryMovementCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager", "supervisor"))):
    item = db.query(InventoryItem).filter(
        InventoryItem.id == payload.item_id,
        InventoryItem.factory_id == user.factory_id,
        InventoryItem.is_active.is_(True),
    ).with_for_update().first()
    if not item:
        raise HTTPException(status_code=404, detail="Inventory item not found")
    previous_quantity = item.quantity_on_hand
    delta = payload.quantity if payload.movement_type == "in" else -payload.quantity
    resulting_quantity = previous_quantity + delta
    if resulting_quantity < 0:
        raise HTTPException(status_code=409, detail="Stock issue exceeds the quantity on hand")
    item.quantity_on_hand = resulting_quantity
    movement = InventoryMovement(
        factory_id=user.factory_id, item_id=item.id, movement_type=payload.movement_type,
        quantity=payload.quantity, previous_quantity=previous_quantity,
        resulting_quantity=resulting_quantity, reason=payload.reason, reference=payload.reference,
        created_by=user.id,
    )
    db.add(movement)
    db.commit()
    db.refresh(movement)
    return movement


@app.get("/api/maintenance", response_model=list[MaintenanceOrderOut])
def list_maintenance_orders(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return scoped(db.query(MaintenanceOrder), MaintenanceOrder, user).order_by(MaintenanceOrder.due_date, MaintenanceOrder.id.desc()).limit(500).all()


@app.post("/api/maintenance", response_model=MaintenanceOrderOut, status_code=201)
def create_maintenance_order(payload: MaintenanceOrderCreate, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "manager", "supervisor"))):
    validate_machine(db, payload.machine_id, user.factory_id)
    validate_assignee(db, payload.assigned_to, user.factory_id)
    order = MaintenanceOrder(factory_id=user.factory_id, created_by=user.id, **payload.model_dump())
    db.add(order)
    db.commit()
    db.refresh(order)
    return order


@app.patch("/api/maintenance/{order_id}", response_model=MaintenanceOrderOut)
def update_maintenance_order(order_id: int, payload: MaintenanceOrderUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    order = db.query(MaintenanceOrder).filter(
        MaintenanceOrder.id == order_id,
        MaintenanceOrder.factory_id == user.factory_id,
    ).with_for_update().first()
    if not order:
        raise HTTPException(status_code=404, detail="Maintenance order not found")
    if user.role not in {"admin", "manager", "supervisor"} and order.assigned_to != user.id:
        raise HTTPException(status_code=403, detail="You can only update maintenance assigned to you")
    if user.role == "operator" and payload.status not in {"in_progress", "completed"}:
        raise HTTPException(status_code=403, detail="Operators can only start or complete their assigned maintenance")
    if payload.status == "completed" and len(payload.completion_notes.strip()) < 3:
        raise HTTPException(status_code=422, detail="Add a completion note before closing the maintenance order")
    transitions = {
        "planned": {"planned", "in_progress", "cancelled"},
        "in_progress": {"in_progress", "completed", "cancelled"},
        "completed": {"completed"},
        "cancelled": {"cancelled"},
    }
    if payload.status not in transitions.get(order.status, set()):
        raise HTTPException(status_code=409, detail="This maintenance order cannot move to that status")
    order.status = payload.status
    order.completion_notes = payload.completion_notes
    order.completed_at = utc_now_naive() if payload.status == "completed" else None
    order.updated_at = utc_now_naive()
    machine = db.query(Machine).filter(
        Machine.id == order.machine_id,
        Machine.factory_id == user.factory_id,
    ).with_for_update().first()
    if machine:
        refresh_machine_operational_status(db, machine)
    db.commit()
    db.refresh(order)
    return order


@app.get("/api/productivity")
def productivity(from_date: date | None = None, to_date: date | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    start, end = parse_range(from_date, to_date, factory_today(db, user))
    factory_users = db.query(User).filter(User.factory_id == user.factory_id)
    if user.role == "operator":
        factory_users = factory_users.filter(User.id == user.id)
    people = factory_users.order_by(User.full_name).all()
    activity = {
        person.id: {
            "user_id": person.id, "full_name": person.full_name, "role": person.role,
            "tasks_assigned": 0, "tasks_done": 0, "production_entries": 0,
            "units_recorded": 0, "quality_inspections": 0, "downtime_reports": 0,
            "maintenance_completed": 0,
        }
        for person in people
    }
    start_at, end_at = _factory_period_bounds(db, user, start, end)
    for task in db.query(Task).filter(Task.factory_id == user.factory_id, Task.created_at >= start_at, Task.created_at < end_at).all():
        if task.assigned_to in activity:
            activity[task.assigned_to]["tasks_assigned"] += 1
            if task.status == "done":
                activity[task.assigned_to]["tasks_done"] += 1
    for entry in db.query(ProductionEntry).filter(ProductionEntry.factory_id == user.factory_id, ProductionEntry.production_date.between(start, end)).all():
        if entry.created_by in activity:
            activity[entry.created_by]["production_entries"] += 1
            activity[entry.created_by]["units_recorded"] += entry.actual_quantity
    for inspection in db.query(QualityInspection).filter(QualityInspection.factory_id == user.factory_id, QualityInspection.inspection_date.between(start, end)).all():
        if inspection.created_by in activity:
            activity[inspection.created_by]["quality_inspections"] += 1
    for event in db.query(DowntimeEvent).filter(DowntimeEvent.factory_id == user.factory_id, DowntimeEvent.created_at >= start_at, DowntimeEvent.created_at < end_at).all():
        if event.created_by in activity:
            activity[event.created_by]["downtime_reports"] += 1
    for order in db.query(MaintenanceOrder).filter(MaintenanceOrder.factory_id == user.factory_id, MaintenanceOrder.completed_at.is_not(None), MaintenanceOrder.completed_at >= start_at, MaintenanceOrder.completed_at < end_at).all():
        if order.assigned_to in activity:
            activity[order.assigned_to]["maintenance_completed"] += 1
    return {
        "range": {"from_date": start.isoformat(), "to_date": end.isoformat()},
        "definition": "Recorded work activity only; this is not an automated employee rating.",
        "people": list(activity.values()),
    }


def _factory_period_bounds(db: Session, user: User, start: date, end: date):
    local_timezone = factory_timezone(db, user)
    start_at = datetime.combine(start, datetime.min.time(), tzinfo=local_timezone).astimezone(timezone.utc).replace(tzinfo=None)
    end_at = datetime.combine(end + timedelta(days=1), datetime.min.time(), tzinfo=local_timezone).astimezone(timezone.utc).replace(tzinfo=None)
    return start_at, end_at


@app.get("/api/dashboard")
def dashboard(
    from_date: date | None = None, to_date: date | None = None,
    db: Session = Depends(get_db), user: User = Depends(get_current_user),
):
    start, end = parse_range(from_date, to_date, factory_today(db, user))
    production_query = scoped(db.query(ProductionEntry), ProductionEntry, user).filter(ProductionEntry.production_date.between(start, end))
    target, actual = production_query.with_entities(
        func.coalesce(func.sum(ProductionEntry.target_quantity), 0),
        func.coalesce(func.sum(ProductionEntry.actual_quantity), 0),
    ).one()
    daily_production = production_query.with_entities(
        ProductionEntry.production_date,
        func.sum(ProductionEntry.target_quantity),
        func.sum(ProductionEntry.actual_quantity),
    ).group_by(ProductionEntry.production_date).order_by(ProductionEntry.production_date).all()
    quality_query = scoped(db.query(QualityInspection), QualityInspection, user).filter(QualityInspection.inspection_date.between(start, end))
    inspected, rejected = quality_query.with_entities(
        func.coalesce(func.sum(QualityInspection.inspected_quantity), 0),
        func.coalesce(func.sum(QualityInspection.rejected_quantity), 0),
    ).one()
    local_timezone = factory_timezone(db, user)
    period_start = datetime.combine(start, datetime.min.time(), tzinfo=local_timezone).astimezone(timezone.utc).replace(tzinfo=None)
    period_end = datetime.combine(end + timedelta(days=1), datetime.min.time(), tzinfo=local_timezone).astimezone(timezone.utc).replace(tzinfo=None)
    downtime_events = scoped(db.query(DowntimeEvent), DowntimeEvent, user).filter(
        DowntimeEvent.started_at < period_end,
        or_(DowntimeEvent.ended_at.is_(None), DowntimeEvent.ended_at > period_start),
    ).all()
    now = utc_now_naive()
    downtime_minutes = 0
    open_events = 0
    for event in downtime_events:
        overlap_start = max(event.started_at, period_start)
        overlap_end = min(event.ended_at or now, period_end, now)
        if overlap_end <= overlap_start:
            continue
        downtime_minutes += max(0, int((overlap_end - overlap_start).total_seconds() // 60))
        if event.status == "open":
            open_events += 1
    total_tasks, open_tasks = scoped(db.query(Task), Task, user).with_entities(
        func.count(Task.id),
        func.coalesce(func.sum(case((Task.status != "done", 1), else_=0)), 0),
    ).one()
    return {
        "range": {"from_date": start.isoformat(), "to_date": end.isoformat()},
        "production": {"target": target, "actual": actual, "achievement_percent": round((actual / target * 100), 1) if target else 0},
        "quality": {"inspected": inspected, "rejected": rejected, "rejection_percent": round((rejected / inspected * 100), 2) if inspected else 0, "accepted": inspected - rejected},
        "downtime": {"minutes": downtime_minutes, "open_events": open_events},
        "tasks": {"open": int(open_tasks), "total": int(total_tasks)},
        "recent_production": [
            {"date": day.isoformat(), "target": daily_target, "actual": daily_actual}
            for day, daily_target, daily_actual in daily_production
        ],
    }


@app.get("/api/insights")
def insights(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    today = factory_today(db, user)
    start = today - timedelta(days=6)
    data = dashboard(start, today, db, user)
    items = []
    prod = data["production"]
    quality = data["quality"]
    if prod["target"] and prod["achievement_percent"] < 90:
        items.append({"level": "warning", "title": "Production is below target", "detail": f"The selected 7-day production achievement is {prod['achievement_percent']}%. Review shift-wise output and open bottlenecks."})
    elif prod["target"]:
        items.append({"level": "success", "title": "Production is on track", "detail": f"Production achievement is {prod['achievement_percent']}% across the last 7 days."})
    if quality["inspected"] and quality["rejection_percent"] >= 3:
        items.append({"level": "danger", "title": "Review product rejection trend", "detail": f"Rejection rate is {quality['rejection_percent']}%. Check defect categories, batches and process settings."})
    elif quality["inspected"]:
        items.append({"level": "success", "title": "Quality rejection rate is controlled", "detail": f"Recorded rejection rate is {quality['rejection_percent']}% for the last 7 days."})
    open_downtime = db.query(DowntimeEvent).filter(DowntimeEvent.factory_id == user.factory_id, DowntimeEvent.status == "open").count()
    if open_downtime:
        items.append({"level": "warning", "title": f"{open_downtime} machine downtime event(s) remain open", "detail": "Assign a technician, add a resolution note outside the app if needed, and close the event when the machine is verified as running."})
    overdue = db.query(Task).filter(Task.factory_id == user.factory_id, Task.status != "done", Task.due_date < today).count()
    if overdue:
        items.append({"level": "danger", "title": f"{overdue} task(s) are overdue", "detail": "Review owners and due dates during the production meeting."})
    low_stock = db.query(InventoryItem).filter(
        InventoryItem.factory_id == user.factory_id,
        InventoryItem.is_active.is_(True),
        InventoryItem.reorder_level > 0,
        InventoryItem.quantity_on_hand <= InventoryItem.reorder_level,
    ).order_by(InventoryItem.quantity_on_hand).limit(5).all()
    if low_stock:
        names = ", ".join(item.name for item in low_stock)
        items.append({"level": "warning", "title": f"{len(low_stock)} inventory item(s) are at or below reorder level", "detail": f"Review purchasing for: {names}. Compare available stock with open orders before replenishing."})
    overdue_maintenance = db.query(MaintenanceOrder).filter(
        MaintenanceOrder.factory_id == user.factory_id,
        MaintenanceOrder.status.in_(("planned", "in_progress")),
        MaintenanceOrder.due_date < today,
    ).count()
    if overdue_maintenance:
        items.append({"level": "danger", "title": f"{overdue_maintenance} maintenance order(s) are overdue", "detail": "Review the assigned technician and machine condition, then update the order after the work is verified."})
    if not items:
        items.append({"level": "info", "title": "Not enough operating data yet", "detail": "Record production, quality inspections and machine events to generate operational observations."})
    return {"provider": "rules-based-demo", "disclaimer": "These are transparent rule-based observations, not predictive AI or engineering advice.", "items": items}


@app.get("/api/reports/export.csv")
def export_csv(kind: str = Query(pattern="^(production|quality|downtime|tasks|inventory|maintenance|productivity)$"), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    output = StringIO()
    writer = csv.writer(output)
    def write_row(values):
        safe_values = []
        for value in values:
            if isinstance(value, str) and value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")):
                value = "'" + value
            safe_values.append(value)
        writer.writerow(safe_values)

    if kind == "production":
        rows = scoped(db.query(ProductionEntry), ProductionEntry, user).order_by(ProductionEntry.production_date.desc()).limit(5000).all()
        write_row(["id", "date", "product_id", "shift", "line", "target", "actual", "notes"])
        for r in rows: write_row([r.id, r.production_date, r.product_id, r.shift, r.production_line, r.target_quantity, r.actual_quantity, r.notes])
    elif kind == "quality":
        rows = scoped(db.query(QualityInspection), QualityInspection, user).order_by(QualityInspection.inspection_date.desc()).limit(5000).all()
        write_row(["id", "date", "product_id", "batch", "inspected", "rejected", "defect_type", "notes"])
        for r in rows: write_row([r.id, r.inspection_date, r.product_id, r.batch_number, r.inspected_quantity, r.rejected_quantity, r.defect_type, r.notes])
    elif kind == "downtime":
        rows = scoped(db.query(DowntimeEvent), DowntimeEvent, user).order_by(DowntimeEvent.started_at.desc()).limit(5000).all()
        write_row(["id", "machine_id", "started_at", "ended_at", "minutes", "reason", "status"])
        now = utc_now_naive()
        for r in rows:
            minutes = max(0, int((now - r.started_at).total_seconds() // 60)) if r.status == "open" else r.downtime_minutes
            write_row([r.id, r.machine_id, r.started_at, r.ended_at, minutes, r.reason, r.status])
    elif kind == "tasks":
        rows = scoped(db.query(Task), Task, user).order_by(Task.created_at.desc()).limit(5000).all()
        write_row(["id", "title", "priority", "status", "due_date", "assigned_to", "description"])
        for r in rows: write_row([r.id, r.title, r.priority, r.status, r.due_date, r.assigned_to, r.description])
    elif kind == "inventory":
        rows = scoped(db.query(InventoryItem), InventoryItem, user).filter(InventoryItem.is_active.is_(True)).order_by(InventoryItem.name).limit(5000).all()
        write_row(["id", "sku", "name", "category", "unit", "quantity_on_hand", "reorder_level", "location"])
        for r in rows: write_row([r.id, r.sku, r.name, r.category, r.unit, r.quantity_on_hand, r.reorder_level, r.location])
    elif kind == "maintenance":
        rows = scoped(db.query(MaintenanceOrder), MaintenanceOrder, user).order_by(MaintenanceOrder.due_date, MaintenanceOrder.id).limit(5000).all()
        write_row(["id", "machine_id", "title", "maintenance_type", "priority", "status", "due_date", "assigned_to", "completion_notes"])
        for r in rows: write_row([r.id, r.machine_id, r.title, r.maintenance_type, r.priority, r.status, r.due_date, r.assigned_to, r.completion_notes])
    else:
        start, end = parse_range(None, None, factory_today(db, user))
        summary = productivity(start, end, db, user)
        write_row(["user_id", "full_name", "role", "tasks_assigned", "tasks_done", "production_entries", "units_recorded", "quality_inspections", "downtime_reports", "maintenance_completed"])
        for person in summary["people"]:
            write_row([person[key] for key in ("user_id", "full_name", "role", "tasks_assigned", "tasks_done", "production_entries", "units_recorded", "quality_inspections", "downtime_reports", "maintenance_completed")])
    output.seek(0)
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=udyogos-{kind}.csv"})


app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
