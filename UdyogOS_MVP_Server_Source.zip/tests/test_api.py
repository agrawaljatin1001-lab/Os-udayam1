import csv
import os
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from io import StringIO

# Keep automated checks isolated from a developer's local database and any production URL.
os.environ["ENVIRONMENT"] = "development"
os.environ["DATABASE_URL"] = "sqlite:///./tests/test_udyogos.db"
os.environ["SECRET_KEY"] = "pytest-only-secret-key-never-use-in-production"

import pytest
from fastapi.testclient import TestClient

from app.database import Base, SessionLocal, engine
from app.config import Settings
from app.main import app
from app.models import DowntimeEvent, Factory, Machine, Product, ProductionEntry, QualityInspection, Task, User, InventoryItem, InventoryMovement, MaintenanceOrder
from app.seed import seed_demo_data
from app.security import create_access_token, hash_password


@pytest.fixture(autouse=True)
def isolated_database():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_demo_data(db)
    finally:
        db.close()
    yield


def login(client, email="admin@udyogos.demo", password="Demo@12345"):
    response = client.post("/api/auth/login", data={"username": email, "password": password})
    assert response.status_code == 200
    return response.json()["access_token"]


def auth(token):
    return {"Authorization": f"Bearer {token}"}


def test_health_checks_database_connection():
    with TestClient(app) as client:
        response = client.get("/api/health")
        assert response.status_code == 200
        assert response.json()["status"] == "ok"
        assert response.json()["database"] == "connected"


def test_production_configuration_requires_secure_persistent_database():
    with pytest.raises(ValueError):
        Settings(
            environment="production", secret_key="a" * 64, database_url="sqlite:///./unsafe.db",
            bootstrap_factory_name="Factory", bootstrap_admin_name="Owner",
            bootstrap_admin_email="owner@example.com", bootstrap_admin_password="a-secure-password-123",
            cors_origins="",
        )
    with pytest.raises(ValueError, match="PLATFORM_ADMIN"):
        Settings(
            environment="production", secret_key="a" * 64,
            database_url="postgresql+psycopg://user:password@localhost/udyogos",
            cors_origins="https://udyogos.example",
        )


def test_authentication_and_dashboard_aggregate():
    with TestClient(app) as client:
        denied = client.get("/api/dashboard")
        assert denied.status_code == 401
        assert client.post("/api/auth/login", data={"username": "admin@udyogos.demo", "password": "wrong"}).status_code == 401
        dashboard = client.get("/api/dashboard", headers=auth(login(client)))
        assert dashboard.status_code == 200
        assert dashboard.json()["production"]["target"] > 0
        assert "recent_production" in dashboard.json()


def test_business_can_register_its_own_workspace_and_login_by_email_or_username():
    with TestClient(app) as client:
        payload = {
            "business_name": "North Star Manufacturing",
            "business_email": "contact@northstar.example",
            "city": "Indore", "timezone": "Asia/Kolkata",
            "owner_name": "Nisha Patel", "owner_email": "nisha@northstar.example",
            "username": "nisha.patel", "password": "northstar-secure-12345",
        }
        created = client.post("/api/auth/register", json=payload)
        assert created.status_code == 201
        token = created.json()["access_token"]
        assert created.json()["user"]["username"] == "nisha.patel"
        profile = client.get("/api/factory", headers=auth(token))
        assert profile.status_code == 200
        assert profile.json()["name"] == payload["business_name"]
        assert profile.json()["business_email"] == payload["business_email"]
        changed_profile = client.patch("/api/factory", headers=auth(token), json={
            "name": "North Star Components", "business_email": "office@northstar.example",
            "city": "Dewas", "timezone": "Asia/Kolkata",
        })
        assert changed_profile.status_code == 200
        assert changed_profile.json()["name"] == "North Star Components"
        assert client.post("/api/auth/login", data={"username": "NISHA.PATEL", "password": payload["password"]}).status_code == 200
        assert client.post("/api/auth/login", data={"username": payload["owner_email"], "password": payload["password"]}).status_code == 200

        product = client.post("/api/products", headers=auth(token), json={"name": "North Star Part", "sku": "NS-1", "unit": "pcs"})
        assert product.status_code == 201
        other = {**payload, "business_name": "South Ridge Manufacturing", "business_email": "contact@southridge.example", "owner_email": "arun@southridge.example", "owner_name": "Arun Shah", "username": "arun.shah"}
        second = client.post("/api/auth/register", json=other)
        assert second.status_code == 201
        assert client.get("/api/products", headers=auth(second.json()["access_token"])).json() == []
        assert len(client.get("/api/products", headers=auth(token)).json()) == 1

        duplicate_email = {**other, "business_name": "Third Factory", "business_email": other["business_email"], "owner_email": "owner3@example.com", "username": "owner.three"}
        assert client.post("/api/auth/register", json=duplicate_email).status_code == 409
        duplicate_business_email = client.patch("/api/factory", headers=auth(token), json={
            "name": "North Star Components", "business_email": other["business_email"],
            "city": "Dewas", "timezone": "Asia/Kolkata",
        })
        assert duplicate_business_email.status_code == 409


def test_platform_admin_manages_businesses_from_the_same_site_and_suspension_revokes_sessions():
    db = SessionLocal()
    try:
        platform_admin = User(
            factory_id=None, full_name="Platform Admin", username="platform.testadmin",
            email="platform@example.com", password_hash=hash_password("platform-admin-password-123"),
            role="platform_admin",
        )
        db.add(platform_admin)
        db.commit()
        platform_token = create_access_token(str(platform_admin.id), platform_admin.token_version)
    finally:
        db.close()

    with TestClient(app) as client:
        platform_login = client.post("/api/auth/login", data={"username": "platform@example.com", "password": "platform-admin-password-123"})
        assert platform_login.status_code == 200
        assert platform_login.json()["user"]["role"] == "platform_admin"
        business = {
            "business_name": "Central Admin Test Co", "business_email": "contact@centraltest.example",
            "city": "Bhopal", "timezone": "Asia/Kolkata", "owner_name": "Owner One",
            "owner_email": "owner@centraltest.example", "username": "central.owner",
            "password": "central-owner-password-123",
        }
        headers = auth(platform_token)
        created = client.post("/api/platform/factories", headers=headers, json=business)
        assert created.status_code == 201
        workspace = created.json()
        assert workspace["business_email"] == business["business_email"]
        assert workspace["user_count"] == 1
        owner_token = client.post("/api/auth/login", data={"username": business["username"], "password": business["password"]}).json()["access_token"]
        assert client.get("/api/platform/factories", headers=auth(login(client))).status_code == 403
        registry = client.get("/api/platform/users", headers=headers)
        assert registry.status_code == 200
        owner = next(account for account in registry.json() if account["email"] == business["owner_email"])
        assert owner["business_name"] == business["business_name"]
        assert client.get("/api/platform/users", headers=auth(login(client))).status_code == 403
        last_admin = {"full_name": owner["full_name"], "email": owner["email"], "username": owner["username"], "role": "supervisor", "is_active": True}
        assert client.patch(f"/api/platform/users/{owner['id']}", headers=headers, json=last_admin).status_code == 409
        reset = client.post(f"/api/platform/users/{owner['id']}/reset-password", headers=headers, json={"password": "platform-reset-owner-123"})
        assert reset.status_code == 200
        assert client.get("/api/auth/me", headers=auth(owner_token)).status_code == 401
        assert client.post("/api/auth/login", data={"username": business["username"], "password": "platform-reset-owner-123"}).status_code == 200

        edited = {
            "name": "Central Admin Test Manufacturing", "business_email": business["business_email"],
            "city": "Indore", "timezone": "Asia/Kolkata", "is_active": False,
        }
        suspended = client.patch(f"/api/platform/factories/{workspace['id']}", headers=headers, json=edited)
        assert suspended.status_code == 200
        assert suspended.json()["is_active"] is False
        assert client.post("/api/auth/login", data={"username": business["username"], "password": "platform-reset-owner-123"}).status_code == 401

        edited["is_active"] = True
        restored = client.patch(f"/api/platform/factories/{workspace['id']}", headers=headers, json=edited)
        assert restored.status_code == 200
        assert restored.json()["is_active"] is True
        assert client.post("/api/auth/login", data={"username": business["username"], "password": "platform-reset-owner-123"}).status_code == 200
        summary = client.get("/api/platform/dashboard", headers=headers)
        assert summary.status_code == 200
        assert summary.json()["businesses"] == 2
        assert len(client.get("/api/platform/factories", headers=headers).json()) == 2


def test_admin_can_create_team_account_and_user_can_sign_in():
    with TestClient(app) as client:
        response = client.post("/api/users", headers=auth(login(client)), json={
            "full_name": "  New Operator  ", "email": "NEW.OPERATOR@example.com",
            "username": "new.operator",
            "password": "a-unique-password-123", "role": "operator",
        })
        assert response.status_code == 201
        assert response.json()["email"] == "new.operator@example.com"
        assert "password" not in response.json()
        assert client.post("/api/auth/login", data={"username": "new.operator@example.com", "password": "a-unique-password-123"}).status_code == 200
        assert client.post("/api/auth/login", data={"username": "NEW.OPERATOR", "password": "a-unique-password-123"}).status_code == 200


def test_only_admin_can_create_users_and_duplicate_email_is_rejected():
    with TestClient(app) as client:
        payload = {"full_name": "Second Operator", "email": "OPERATOR@UDYOGOS.DEMO", "username": "another.operator", "password": "a-unique-password-123", "role": "operator"}
        assert client.post("/api/users", headers=auth(login(client, "manager@udyogos.demo")), json=payload).status_code == 403
        assert client.post("/api/users", headers=auth(login(client)), json=payload).status_code == 409
        assert client.get("/api/admin/users", headers=auth(login(client, "manager@udyogos.demo"))).status_code == 403


def test_admin_manages_accounts_and_password_reset_revokes_existing_sessions():
    with TestClient(app) as client:
        admin_headers = auth(login(client))
        operator = next(user for user in client.get("/api/admin/users", headers=admin_headers).json() if user["email"] == "operator@udyogos.demo")
        operator_token = login(client, "operator@udyogos.demo")
        update = {
            "full_name": "Updated Operator", "email": "updated.operator@example.com",
            "username": "updated.operator",
            "role": "supervisor", "is_active": False,
        }
        changed = client.patch(f"/api/users/{operator['id']}", headers=admin_headers, json=update)
        assert changed.status_code == 200
        assert changed.json()["is_active"] is False
        assert client.get("/api/auth/me", headers=auth(operator_token)).status_code == 401
        assert client.post("/api/auth/login", data={"username": update["email"], "password": "Demo@12345"}).status_code == 401
        assert all(user["email"] != "updated.operator@example.com" for user in client.get("/api/users", headers=admin_headers).json())

        update["is_active"] = True
        assert client.patch(f"/api/users/{operator['id']}", headers=admin_headers, json=update).status_code == 200
        active_token = login(client, update["email"], "Demo@12345")
        reset = client.post(f"/api/users/{operator['id']}/reset-password", headers=admin_headers, json={"password": "new-temporary-password-123"})
        assert reset.status_code == 200
        assert client.get("/api/auth/me", headers=auth(active_token)).status_code == 401
        assert client.post("/api/auth/login", data={"username": update["email"], "password": "new-temporary-password-123"}).status_code == 200


def test_admin_cannot_remove_the_last_admin_or_deactivate_self():
    with TestClient(app) as client:
        headers = auth(login(client))
        owner = next(user for user in client.get("/api/admin/users", headers=headers).json() if user["email"] == "admin@udyogos.demo")
        demote_payload = {"full_name": owner["full_name"], "email": owner["email"], "username": owner["username"], "role": "operator", "is_active": True}
        demote = client.patch(f"/api/users/{owner['id']}", headers=headers, json=demote_payload)
        assert demote.status_code == 409
        disable_payload = {**demote_payload, "role": "admin", "is_active": False}
        disable = client.patch(f"/api/users/{owner['id']}", headers=headers, json=disable_payload)
        assert disable.status_code == 409


def test_products_machines_and_duplicate_codes():
    with TestClient(app) as client:
        headers = auth(login(client))
        product = {"name": "New Bracket", "sku": "NB-1", "unit": "pcs"}
        assert client.post("/api/products", headers=headers, json=product).status_code == 201
        assert client.post("/api/products", headers=headers, json=product).status_code == 409
        machine = {"name": "New CNC", "code": "CNC-X", "production_line": "Line X"}
        assert client.post("/api/machines", headers=headers, json=machine).status_code == 201
        assert client.post("/api/machines", headers=headers, json=machine).status_code == 409


def test_inventory_ledger_updates_balances_and_blocks_negative_stock():
    with TestClient(app) as client:
        manager_headers = auth(login(client, "manager@udyogos.demo"))
        operator_headers = auth(login(client, "operator@udyogos.demo"))
        payload = {
            "sku": "  RM-TEST-9 ", "name": " Test Resin ", "category": "Raw material",
            "unit": "kg", "quantity_on_hand": "10.250", "reorder_level": "4.000", "location": "Store B",
        }
        created = client.post("/api/inventory", headers=manager_headers, json=payload)
        assert created.status_code == 201
        item = created.json()
        assert item["sku"] == "RM-TEST-9"
        assert float(item["quantity_on_hand"]) == 10.25
        opening = client.get(f"/api/inventory/movements?item_id={item['id']}", headers=manager_headers)
        assert opening.status_code == 200
        assert opening.json()[0]["movement_type"] == "opening"

        received = client.post("/api/inventory/movements", headers=manager_headers, json={
            "item_id": item["id"], "movement_type": "in", "quantity": "5.500", "reason": "Supplier delivery", "reference": "PO-55",
        })
        assert received.status_code == 201
        issued = client.post("/api/inventory/movements", headers=manager_headers, json={
            "item_id": item["id"], "movement_type": "out", "quantity": "3.250", "reason": "Production use",
        })
        assert issued.status_code == 201
        assert float(issued.json()["resulting_quantity"]) == 12.5
        short_stock = client.post("/api/inventory/movements", headers=manager_headers, json={
            "item_id": item["id"], "movement_type": "out", "quantity": "99", "reason": "Excess issue",
        })
        assert short_stock.status_code == 409
        assert float(next(row for row in client.get("/api/inventory", headers=manager_headers).json() if row["id"] == item["id"])["quantity_on_hand"]) == 12.5
        assert client.post("/api/inventory", headers=manager_headers, json={**payload, "sku": "rm-test-9", "name": "Duplicate resin"}).status_code == 409
        assert client.post("/api/inventory", headers=operator_headers, json={**payload, "sku": "OP-ITEM-1"}).status_code == 403
        edited = client.patch(f"/api/inventory/{item['id']}", headers=manager_headers, json={"reorder_level": "13", "location": "Store C"})
        assert edited.status_code == 200
        assert float(edited.json()["reorder_level"]) == 13
        assert edited.json()["location"] == "Store C"
        assert "RM-TEST-9" in client.get("/api/reports/export.csv?kind=inventory", headers=manager_headers).text


def test_maintenance_workflow_updates_machine_and_operator_activity():
    with TestClient(app) as client:
        manager_headers = auth(login(client, "manager@udyogos.demo"))
        operator_headers = auth(login(client, "operator@udyogos.demo"))
        machine = client.get("/api/machines", headers=manager_headers).json()[0]
        operator = next(user for user in client.get("/api/users", headers=manager_headers).json() if user["role"] == "operator")
        created = client.post("/api/maintenance", headers=manager_headers, json={
            "machine_id": machine["id"], "title": "Inspect spindle", "description": "Check vibration and lubrication.",
            "maintenance_type": "preventive", "priority": "high", "due_date": date.today().isoformat(),
            "assigned_to": operator["id"],
        })
        assert created.status_code == 201
        order_id = created.json()["id"]
        assert client.patch(f"/api/maintenance/{order_id}", headers=operator_headers, json={"status": "in_progress"}).status_code == 200
        machine_after_start = next(row for row in client.get("/api/machines", headers=manager_headers).json() if row["id"] == machine["id"])
        assert machine_after_start["status"] == "maintenance"
        assert client.patch(f"/api/maintenance/{order_id}", headers=operator_headers, json={"status": "completed"}).status_code == 422
        completed = client.patch(f"/api/maintenance/{order_id}", headers=operator_headers, json={
            "status": "completed", "completion_notes": "Inspected and lubricated; verified running.",
        })
        assert completed.status_code == 200
        assert completed.json()["completed_at"]
        machine_after_close = next(row for row in client.get("/api/machines", headers=manager_headers).json() if row["id"] == machine["id"])
        assert machine_after_close["status"] == "running"
        own_activity = client.get("/api/productivity", headers=operator_headers)
        assert own_activity.status_code == 200
        assert len(own_activity.json()["people"]) == 1
        assert own_activity.json()["people"][0]["user_id"] == operator["id"]
        assert own_activity.json()["people"][0]["maintenance_completed"] == 1
        assert "Inspect spindle" in client.get("/api/reports/export.csv?kind=maintenance", headers=manager_headers).text


def test_tenant_isolation_for_inventory_maintenance_and_productivity():
    db = SessionLocal()
    try:
        factory = Factory(name="Isolated Works", business_email="private@isolated.example", city="Surat", timezone="Asia/Kolkata")
        db.add(factory)
        db.flush()
        user = User(factory_id=factory.id, full_name="Private Owner", username="private.owner", email="private.owner@example.com", password_hash=hash_password("private-owner-password-123"), role="admin")
        machine = Machine(factory_id=factory.id, name="Private Lathe", code="ISO-L1", production_line="Isolated")
        item = InventoryItem(factory_id=factory.id, sku="ISO-RM-1", name="Private steel", category="Raw", unit="kg", quantity_on_hand=Decimal("20"), reorder_level=Decimal("5"), location="Private store")
        db.add_all([user, machine, item])
        db.flush()
        order = MaintenanceOrder(factory_id=factory.id, machine_id=machine.id, title="Private service", due_date=date(2000, 1, 2), created_by=user.id, assigned_to=user.id)
        movement = InventoryMovement(factory_id=factory.id, item_id=item.id, movement_type="opening", quantity=Decimal("20"), previous_quantity=Decimal("0"), resulting_quantity=Decimal("20"), reason="Opening stock", created_by=user.id)
        db.add_all([order, movement])
        db.commit()
        token = create_access_token(str(user.id), user.token_version)
    finally:
        db.close()
    with TestClient(app) as client:
        private_headers = auth(token)
        assert [row["name"] for row in client.get("/api/inventory", headers=private_headers).json()] == ["Private steel"]
        assert [row["title"] for row in client.get("/api/maintenance", headers=private_headers).json()] == ["Private service"]
        assert len(client.get("/api/inventory/movements", headers=private_headers).json()) == 1
        owner_headers = auth(login(client))
        assert all(row["name"] != "Private steel" for row in client.get("/api/inventory", headers=owner_headers).json())
        assert all(row["title"] != "Private service" for row in client.get("/api/maintenance", headers=owner_headers).json())
        assert all(row["full_name"] != "Private Owner" for row in client.get("/api/productivity", headers=owner_headers).json()["people"])


def test_quality_validation_and_operator_permissions():
    with TestClient(app) as client:
        operator_headers = auth(login(client, "operator@udyogos.demo"))
        product_id = client.get("/api/products", headers=operator_headers).json()[0]["id"]
        bad_counts = {"product_id": product_id, "inspection_date": "2026-11-13", "inspected_quantity": 10, "rejected_quantity": 11, "defect_type": "Test defect"}
        assert client.post("/api/quality", headers=auth(login(client)), json=bad_counts).status_code == 422
        assert client.post("/api/quality", headers=operator_headers, json={**bad_counts, "rejected_quantity": 1}).status_code == 403


def test_downtime_lifecycle_updates_machine_status():
    with TestClient(app) as client:
        headers = auth(login(client, "manager@udyogos.demo"))
        machine = client.get("/api/machines", headers=headers).json()[0]
        started_at = (datetime.now(timezone.utc) - timedelta(minutes=35)).isoformat()
        created = client.post("/api/downtime", headers=headers, json={"machine_id": machine["id"], "reason": "Vibration observed", "started_at": started_at})
        assert created.status_code == 201
        assert client.get("/api/machines", headers=headers).json()[0]["status"] == "down"
        export = client.get("/api/reports/export.csv?kind=downtime", headers=headers)
        exported_rows = list(csv.reader(StringIO(export.text)))
        created_row = next(row for row in exported_rows[1:] if int(row[0]) == created.json()["id"])
        assert int(created_row[4]) >= 34
        resolved = client.patch(f"/api/downtime/{created.json()['id']}/resolve", headers=headers)
        assert resolved.status_code == 200
        assert resolved.json()["status"] == "resolved"
        assert client.get("/api/machines", headers=headers).json()[0]["status"] == "running"


def test_dashboard_downtime_date_range_uses_factory_timezone():
    with TestClient(app) as client:
        headers = auth(login(client))
        created = client.post("/api/downtime", headers=headers, json={
            "reason": "Timezone boundary check",
            "started_at": "1999-12-31T19:00:00+00:00",
        })
        assert created.status_code == 201
        dashboard = client.get("/api/dashboard?from_date=2000-01-01&to_date=2000-01-01", headers=headers)
        assert dashboard.status_code == 200
        assert dashboard.json()["downtime"]["open_events"] == 1


def test_tasks_respect_operator_scope_and_export_csv():
    with TestClient(app) as client:
        admin_headers = auth(login(client))
        task = client.post("/api/tasks", headers=admin_headers, json={"title": "=SUM(1,1)", "priority": "high"})
        assert task.status_code == 201
        operator_headers = auth(login(client, "operator@udyogos.demo"))
        manager_id = next(user["id"] for user in client.get("/api/users", headers=operator_headers).json() if user["role"] == "manager")
        assert client.patch(f"/api/tasks/{task.json()['id']}", headers=operator_headers, json={"assigned_to": manager_id}).status_code == 403
        csv_response = client.get("/api/reports/export.csv?kind=tasks", headers=admin_headers)
        assert csv_response.status_code == 200
        assert "'=SUM(1,1)" in csv_response.text


def test_tenant_data_isolation():
    db = SessionLocal()
    try:
        factory = Factory(name="Other Factory", city="Other City", timezone="Asia/Kolkata")
        db.add(factory)
        db.flush()
        user = User(factory_id=factory.id, full_name="Other Owner", username="other.owner", email="other@example.com", password_hash=hash_password("another-secure-password"), role="admin")
        product = Product(factory_id=factory.id, name="Private Item", sku="PRIVATE-1", unit="pcs")
        machine = Machine(factory_id=factory.id, name="Private Machine", code="PRIVATE-M1", production_line="Private Line")
        db.add_all([user, product, machine])
        db.flush()
        production = ProductionEntry(factory_id=factory.id, product_id=product.id, production_date=date(2000, 1, 2), shift="A", production_line="Private Line", target_quantity=10, actual_quantity=8, created_by=user.id)
        quality = QualityInspection(factory_id=factory.id, product_id=product.id, inspection_date=date(2000, 1, 2), batch_number="PRIVATE-BATCH", inspected_quantity=10, rejected_quantity=1, defect_type="Private defect", created_by=user.id)
        downtime = DowntimeEvent(factory_id=factory.id, machine_id=machine.id, started_at=datetime(2000, 1, 2), reason="Private downtime reason", status="open", created_by=user.id)
        task = Task(factory_id=factory.id, title="Private action item", description="Private detail", priority="high", status="open", created_by=user.id)
        db.add_all([production, quality, downtime, task])
        db.commit()
        other_token = create_access_token(str(user.id), user.token_version)
        task_id, downtime_id = task.id, downtime.id
    finally:
        db.close()

    with TestClient(app) as client:
        products = client.get("/api/products", headers=auth(other_token))
        assert products.status_code == 200
        assert [item["name"] for item in products.json()] == ["Private Item"]
        assert [item["email"] for item in client.get("/api/admin/users", headers=auth(other_token)).json()] == ["other@example.com"]
        other_headers = auth(other_token)
        assert client.get("/api/production?from_date=2000-01-01&to_date=2000-12-31", headers=other_headers).json()[0]["production_line"] == "Private Line"
        assert client.get("/api/quality?from_date=2000-01-01&to_date=2000-12-31", headers=other_headers).json()[0]["batch_number"] == "PRIVATE-BATCH"
        assert client.get("/api/downtime", headers=other_headers).json()[0]["reason"] == "Private downtime reason"
        assert client.get("/api/tasks", headers=other_headers).json()[0]["title"] == "Private action item"
        owner_headers = auth(login(client))
        owner_products = client.get("/api/products", headers=owner_headers)
        assert all(item["name"] != "Private Item" for item in owner_products.json())
        assert client.get("/api/production?from_date=2000-01-01&to_date=2000-12-31", headers=owner_headers).json() == []
        assert client.get("/api/quality?from_date=2000-01-01&to_date=2000-12-31", headers=owner_headers).json() == []
        assert all(item["reason"] != "Private downtime reason" for item in client.get("/api/downtime", headers=owner_headers).json())
        assert all(item["title"] != "Private action item" for item in client.get("/api/tasks", headers=owner_headers).json())
        assert client.patch(f"/api/tasks/{task_id}", headers=owner_headers, json={"status": "done"}).status_code == 404
        assert client.patch(f"/api/downtime/{downtime_id}/resolve", headers=owner_headers).status_code == 404
        assert "Private action item" not in client.get("/api/reports/export.csv?kind=tasks", headers=owner_headers).text
        assert client.get("/api/admin/users", headers=owner_headers).status_code == 200
