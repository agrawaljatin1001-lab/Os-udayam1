from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
import jwt
from .database import get_db
from .models import Factory, User
from .security import decode_access_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decode_access_token(token)
        user_id = int(payload.get("sub", ""))
        token_version = int(payload.get("ver", 0))
    except (jwt.PyJWTError, ValueError, TypeError):
        raise credentials_error
    user = db.query(User).filter(User.id == user_id, User.is_active.is_(True)).first()
    if not user or token_version != user.token_version:
        raise credentials_error
    if user.factory_id is not None and not db.query(Factory.id).filter(Factory.id == user.factory_id, Factory.is_active.is_(True)).first():
        raise credentials_error
    return user


def require_roles(*roles: str):
    def checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in roles:
            raise HTTPException(status_code=403, detail="You do not have permission to perform this action")
        return user
    return checker
