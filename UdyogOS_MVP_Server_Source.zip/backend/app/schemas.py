from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
import re
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from pydantic import BaseModel, ConfigDict, Field, field_validator


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class UserOut(ORMModel):
    id: int
    full_name: str
    email: str
    username: str
    role: str
    factory_id: int | None


class UserAdminOut(UserOut):
    is_active: bool
    created_at: datetime


class UserCreate(BaseModel):
    full_name: str = Field(min_length=2, max_length=140)
    email: str = Field(min_length=5, max_length=190)
    username: str = Field(min_length=3, max_length=80, pattern=r"^[A-Za-z0-9._-]+$")
    password: str = Field(min_length=12, max_length=128)
    role: str = Field(pattern="^(admin|manager|supervisor|operator)$")

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        value = value.strip().lower()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value):
            raise ValueError("Enter a valid email address")
        return value

    @field_validator("username")
    @classmethod
    def normalize_username(cls, value: str) -> str:
        return value.strip().lower()

    @field_validator("full_name")
    @classmethod
    def clean_full_name(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Name must contain at least 2 characters")
        return value


class UserUpdate(BaseModel):
    full_name: str = Field(min_length=2, max_length=140)
    email: str = Field(min_length=5, max_length=190)
    username: str = Field(min_length=3, max_length=80, pattern=r"^[A-Za-z0-9._-]+$")
    role: str = Field(pattern="^(admin|manager|supervisor|operator)$")
    is_active: bool

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value: str) -> str:
        value = value.strip().lower()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value):
            raise ValueError("Enter a valid email address")
        return value

    @field_validator("username")
    @classmethod
    def normalize_username(cls, value: str) -> str:
        return value.strip().lower()

    @field_validator("full_name")
    @classmethod
    def clean_full_name(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Name must contain at least 2 characters")
        return value


class PasswordReset(BaseModel):
    password: str = Field(min_length=12, max_length=128)


class FactoryOut(ORMModel):
    id: int
    name: str
    business_email: str
    city: str
    timezone: str
    is_active: bool
    created_at: datetime


class PlatformFactoryOut(FactoryOut):
    user_count: int


class PlatformUserOut(UserAdminOut):
    business_name: str


class FactoryStatusUpdate(BaseModel):
    is_active: bool


class BusinessRegistration(BaseModel):
    business_name: str = Field(min_length=2, max_length=160)
    business_email: str = Field(min_length=5, max_length=190)
    city: str = Field(default="", max_length=100)
    timezone: str = Field(default="Asia/Kolkata", max_length=80)
    owner_name: str = Field(min_length=2, max_length=140)
    owner_email: str = Field(min_length=5, max_length=190)
    username: str = Field(min_length=3, max_length=80, pattern=r"^[A-Za-z0-9._-]+$")
    password: str = Field(min_length=12, max_length=128)

    @field_validator("business_name", "owner_name")
    @classmethod
    def clean_required_names(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Name must contain at least 2 characters")
        return value

    @field_validator("business_email", "owner_email")
    @classmethod
    def normalize_emails(cls, value: str) -> str:
        value = value.strip().lower()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value):
            raise ValueError("Enter a valid email address")
        return value

    @field_validator("username")
    @classmethod
    def normalize_username(cls, value: str) -> str:
        return value.strip().lower()

    @field_validator("city")
    @classmethod
    def clean_city(cls, value: str) -> str:
        return value.strip()

    @field_validator("timezone")
    @classmethod
    def validate_timezone(cls, value: str) -> str:
        value = value.strip()
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError):
            raise ValueError("Enter a valid IANA time zone, such as Asia/Kolkata")
        return value


class FactoryUpdate(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    business_email: str = Field(min_length=5, max_length=190)
    city: str = Field(default="", max_length=100)
    timezone: str = Field(max_length=80)

    @field_validator("name")
    @classmethod
    def clean_factory_name(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Business name must contain at least 2 characters")
        return value

    @field_validator("city")
    @classmethod
    def clean_factory_city(cls, value: str) -> str:
        return value.strip()

    @field_validator("business_email")
    @classmethod
    def normalize_business_email(cls, value: str) -> str:
        value = value.strip().lower()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value):
            raise ValueError("Enter a valid business email address")
        return value

    @field_validator("timezone")
    @classmethod
    def validate_timezone(cls, value: str) -> str:
        value = value.strip()
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError):
            raise ValueError("Enter a valid IANA time zone, such as Asia/Kolkata")
        return value


class PlatformFactoryUpdate(FactoryUpdate):
    is_active: bool


class ProductCreate(BaseModel):
    name: str = Field(min_length=2, max_length=160)
    sku: str = Field(default="", max_length=80)
    unit: str = Field(default="pcs", max_length=30)

    @field_validator("name")
    @classmethod
    def clean_product_name(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Product name must contain at least 2 characters")
        return value

    @field_validator("sku", "unit")
    @classmethod
    def trim_product_optional_fields(cls, value: str) -> str:
        return value.strip()


class MachineCreate(BaseModel):
    name: str = Field(min_length=2, max_length=140)
    code: str = Field(default="", max_length=60)
    production_line: str = Field(min_length=1, max_length=80)

    @field_validator("name")
    @classmethod
    def clean_machine_name(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Machine name must contain at least 2 characters")
        return value

    @field_validator("code")
    @classmethod
    def trim_machine_code(cls, value: str) -> str:
        return value.strip()

    @field_validator("production_line")
    @classmethod
    def clean_machine_line(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Production line is required")
        return value


class ProductionCreate(BaseModel):
    product_id: int | None = None
    production_date: date
    shift: str = Field(default="General", max_length=40)
    production_line: str = Field(min_length=1, max_length=80)
    target_quantity: int = Field(ge=0)
    actual_quantity: int = Field(ge=0)
    notes: str = Field(default="", max_length=2000)

    @field_validator("shift")
    @classmethod
    def clean_shift(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Shift is required")
        return value

    @field_validator("production_line")
    @classmethod
    def clean_production_line(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Production line is required")
        return value


class QualityCreate(BaseModel):
    product_id: int | None = None
    inspection_date: date
    batch_number: str = Field(default="", max_length=90)
    inspected_quantity: int = Field(gt=0)
    rejected_quantity: int = Field(ge=0)
    defect_type: str = Field(default="Not specified", max_length=140)
    notes: str = Field(default="", max_length=2000)

    @field_validator("rejected_quantity")
    @classmethod
    def rejected_cannot_exceed_inspected(cls, value, info):
        inspected = info.data.get("inspected_quantity")
        if inspected is not None and value > inspected:
            raise ValueError("Rejected quantity cannot exceed inspected quantity")
        return value


class DowntimeCreate(BaseModel):
    machine_id: int | None = None
    reason: str = Field(min_length=3, max_length=2000)
    assigned_to: int | None = None
    started_at: datetime | None = None

    @field_validator("reason")
    @classmethod
    def trim_reason(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("Describe the downtime reason in at least 3 characters")
        return value

    @field_validator("started_at")
    @classmethod
    def normalize_started_at(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is not None:
            value = value.astimezone(timezone.utc).replace(tzinfo=None)
        if value > datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(minutes=5):
            raise ValueError("Start time cannot be in the future")
        return value


class TaskCreate(BaseModel):
    title: str = Field(min_length=3, max_length=180)
    description: str = Field(default="", max_length=3000)
    priority: str = Field(default="medium", pattern="^(low|medium|high|critical)$")
    due_date: date | None = None
    assigned_to: int | None = None

    @field_validator("title")
    @classmethod
    def trim_title(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("Task title must contain at least 3 characters")
        return value


class TaskUpdate(BaseModel):
    status: str | None = Field(default=None, pattern="^(open|in_progress|blocked|done)$")
    priority: str | None = Field(default=None, pattern="^(low|medium|high|critical)$")
    assigned_to: int | None = None


class LoginOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut

class ProductOut(ORMModel):
    id: int
    name: str
    sku: str
    unit: str
    is_active: bool


class MachineOut(ORMModel):
    id: int
    name: str
    code: str
    production_line: str
    status: str


class ProductionOut(ORMModel):
    id: int
    product_id: int | None
    production_date: date
    shift: str
    production_line: str
    target_quantity: int
    actual_quantity: int
    notes: str
    created_at: datetime


class QualityOut(ORMModel):
    id: int
    product_id: int | None
    inspection_date: date
    batch_number: str
    inspected_quantity: int
    rejected_quantity: int
    defect_type: str
    notes: str
    created_at: datetime


class DowntimeOut(ORMModel):
    id: int
    machine_id: int | None
    started_at: datetime
    ended_at: datetime | None
    downtime_minutes: int
    reason: str
    status: str
    assigned_to: int | None


class TaskOut(ORMModel):
    id: int
    title: str
    description: str
    priority: str
    status: str
    due_date: date | None
    assigned_to: int | None
    created_at: datetime
    updated_at: datetime


class InventoryItemCreate(BaseModel):
    sku: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=2, max_length=160)
    category: str = Field(default="General", max_length=80)
    unit: str = Field(default="pcs", min_length=1, max_length=30)
    quantity_on_hand: Decimal = Field(default=Decimal("0"), ge=0, max_digits=14, decimal_places=3)
    reorder_level: Decimal = Field(default=Decimal("0"), ge=0, max_digits=14, decimal_places=3)
    location: str = Field(default="", max_length=100)

    @field_validator("sku")
    @classmethod
    def normalize_sku(cls, value: str) -> str:
        value = value.strip().upper()
        if not value:
            raise ValueError("SKU is required")
        return value

    @field_validator("name", "category", "unit", "location")
    @classmethod
    def trim_inventory_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("name")
    @classmethod
    def validate_inventory_name(cls, value: str) -> str:
        if len(value.strip()) < 2:
            raise ValueError("Inventory item name must contain at least 2 characters")
        return value.strip()

    @field_validator("unit")
    @classmethod
    def validate_inventory_unit(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Unit is required")
        return value.strip()


class InventoryItemOut(ORMModel):
    id: int
    sku: str
    name: str
    category: str
    unit: str
    quantity_on_hand: Decimal
    reorder_level: Decimal
    location: str
    is_active: bool
    created_at: datetime


class InventoryItemUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=160)
    category: str | None = Field(default=None, max_length=80)
    unit: str | None = Field(default=None, min_length=1, max_length=30)
    reorder_level: Decimal | None = Field(default=None, ge=0, max_digits=14, decimal_places=3)
    location: str | None = Field(default=None, max_length=100)

    @field_validator("name", "category", "unit", "location")
    @classmethod
    def trim_updated_inventory_text(cls, value: str | None) -> str | None:
        return value.strip() if value is not None else None

    @field_validator("name")
    @classmethod
    def validate_updated_inventory_name(cls, value: str | None) -> str | None:
        if value is not None and len(value) < 2:
            raise ValueError("Inventory item name must contain at least 2 characters")
        return value

    @field_validator("unit")
    @classmethod
    def validate_updated_inventory_unit(cls, value: str | None) -> str | None:
        if value is not None and not value:
            raise ValueError("Unit is required")
        return value


class InventoryMovementCreate(BaseModel):
    item_id: int
    movement_type: str = Field(pattern="^(in|out)$")
    quantity: Decimal = Field(gt=0, max_digits=14, decimal_places=3)
    reason: str = Field(min_length=2, max_length=300)
    reference: str = Field(default="", max_length=100)

    @field_validator("reason", "reference")
    @classmethod
    def trim_movement_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("reason")
    @classmethod
    def validate_movement_reason(cls, value: str) -> str:
        if len(value.strip()) < 2:
            raise ValueError("Explain why the stock moved")
        return value.strip()


class InventoryMovementOut(ORMModel):
    id: int
    item_id: int
    movement_type: str
    quantity: Decimal
    previous_quantity: Decimal
    resulting_quantity: Decimal
    reason: str
    reference: str
    created_by: int
    created_at: datetime


class MaintenanceOrderCreate(BaseModel):
    machine_id: int
    title: str = Field(min_length=3, max_length=180)
    description: str = Field(default="", max_length=3000)
    maintenance_type: str = Field(default="preventive", pattern="^(preventive|corrective)$")
    priority: str = Field(default="medium", pattern="^(low|medium|high|critical)$")
    due_date: date
    assigned_to: int | None = None

    @field_validator("title", "description")
    @classmethod
    def trim_maintenance_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("title")
    @classmethod
    def validate_maintenance_title(cls, value: str) -> str:
        if len(value.strip()) < 3:
            raise ValueError("Maintenance title must contain at least 3 characters")
        return value.strip()


class MaintenanceOrderUpdate(BaseModel):
    status: str = Field(pattern="^(planned|in_progress|completed|cancelled)$")
    completion_notes: str = Field(default="", max_length=3000)

    @field_validator("completion_notes")
    @classmethod
    def trim_completion_notes(cls, value: str) -> str:
        return value.strip()


class MaintenanceOrderOut(ORMModel):
    id: int
    machine_id: int
    title: str
    description: str
    maintenance_type: str
    priority: str
    status: str
    due_date: date
    assigned_to: int | None
    completion_notes: str
    completed_at: datetime | None
    created_by: int
    created_at: datetime
    updated_at: datetime
