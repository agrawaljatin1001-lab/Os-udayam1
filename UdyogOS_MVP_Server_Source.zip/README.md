# UdyogOS — AI Factory Operating System (Pilot MVP)

UdyogOS is a mobile-responsive factory operations starter application. It brings together production records, quality inspections, machine downtime, action tracking, basic factory assets, operational summaries and downloadable CSV reports.

> **Important:** This is an MVP starter project for product discovery and pilot testing. It is not a certified MES, ERP, safety system, quality-release system or predictive-maintenance product. The "AI insights" in this release are explainable rules-based observations, not a trained or predictive AI model. Always keep quality release, machine safety and engineering decisions with qualified people.

## Included in this release

- One responsive website for multiple business workspaces; no separate URL is created for each business.
- Public business registration creates the factory workspace and first owner account; the owner can sign in by email or username.
- A central platform administrator signs in through the same website and can review, create, edit, activate and suspend business workspaces.
- That central admin can also review and manage business owner/team accounts across workspaces, including roles, sign-in access and password resets.
- Unique business contact email, user email and username across the platform; tenant records are scoped to each business workspace.
- Login with password hashing (scrypt) and JWT bearer authentication.
- Factory-scoped data access for the current user.
- Role-aware write permissions for admin, manager, supervisor and operator roles.
- Admin-only account creation and management: edit names/emails/roles, disable or restore sign-in, and reset passwords.
- One website URL with role-based access; admin-only routes are enforced by the backend.
- Product and machine registers.
- Workspace-scoped inventory register with opening balances, receipts, issues, an auditable movement ledger, reorder levels and low-stock signals.
- Preventive/corrective maintenance work orders with due dates, technician assignments, completion notes and machine-state updates.
- Team activity reporting for assigned/completed tasks, production entries, units recorded, inspections, downtime reports and maintenance completions. Operators see their own activity; managers see their workspace team.
- Shift/line production entry with target versus actual reporting.
- Quality inspection entry with validation that rejected quantity cannot exceed inspected quantity.
- Machine downtime reporting, live elapsed duration for open events and supervisor/manager resolution.
- Tasks with owner, due date, priority and status.
- Dashboard KPIs, daily output visualization and rule-based operational signals.
- CSV export for production, quality, downtime and tasks.
- Demo factory, sample records and four demo user roles.
- FastAPI OpenAPI documentation at `/docs`.
- SQLite for local development and PostgreSQL through Docker Compose.

## Demo credentials

All demo accounts use the password `Demo@12345`.

| Role | Email |
|---|---|
| Platform admin | `platform@udyogos.demo` |
| Admin / owner | `admin@udyogos.demo` |
| Manager | `manager@udyogos.demo` |
| Supervisor | `supervisor@udyogos.demo` |
| Operator | `operator@udyogos.demo` |

These accounts and sample records are created only in development mode. Production does not create demo accounts. The central platform administrator is created from `PLATFORM_ADMIN_*` environment values on first startup; business owners can register directly on the website.

## Run locally (Python 3.11+)

1. Extract this folder and open a terminal in the project root.
2. Create and activate a virtual environment:

   **Windows PowerShell**
   ```powershell
   py -3.12 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   **macOS / Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env`. This is for local development and uses SQLite plus demo data; do not use it for a public deployment.
5. Start the API and web app from the project root:
   ```bash
   uvicorn app.main:app --app-dir backend --reload
   ```
6. Open `http://127.0.0.1:8000` and sign in with either the platform admin or business admin demo account above. The platform account opens the central business/user console.
7. API docs are at `http://127.0.0.1:8000/docs`.

The database tables and demo data are created automatically on first development startup. If you want to reset local demo data, stop the server, delete `udyogos.db`, and start it again.

## Run with Docker Compose

1. Copy `.env.production.example` to `.env` on a Docker host.
   ```powershell
   Copy-Item .env.production.example .env
   ```
2. Replace every example value. Generate a unique secret key and database password, enter your real public HTTPS origin, and set the central platform administrator's name, globally unique username and email, and password. Keep `.env` private; it is ignored by Git. Leave the optional `BOOTSTRAP_*` fields blank if businesses will register on the site.
   ```powershell
   py -c "import secrets; print(secrets.token_urlsafe(48))"
   ```
   Use the generated value for `SECRET_KEY`. Use another generated value for `POSTGRES_PASSWORD`. Set a unique platform admin password of at least 12 characters.
3. Run:
   ```bash
   docker compose up --build
   ```
4. Confirm the app health endpoint reports `"database":"connected"` at `http://YOUR-HOST:8000/api/health`.

On a public host, put the app behind HTTPS using the host's reverse proxy or managed certificate and point your domain to that host. The app serves its own frontend and API, so `CORS_ORIGINS` can stay blank for a same-origin deployment; if you host a separate frontend, set it to that frontend's exact HTTPS origin. Keep the `postgres_data` volume persistent and schedule database backups. Production starts without demo workspaces. A platform administrator signs in at the same website and manages all business workspaces from the Platform admin screen. Each business can also register from the same URL; its first registrant becomes that business's owner/admin and manages only its own profile, team, and records from the Admin panel. Optional `BOOTSTRAP_*` settings can pre-create one workspace on an empty database. Store production secrets in your hosting provider's secret manager where available. Share initial and reset passwords privately. User accounts and operational data are scoped to their business; email addresses, usernames, and business contact emails are unique across the platform.

## Deploy to Vercel

The root `pyproject.toml` points Vercel to the FastAPI application, pins the supported Python runtime, and enables CDN delivery for public frontend files. Create or select a Vercel project and connect a managed PostgreSQL database (for example, a Neon Marketplace database), then set these variables in the Vercel Production environment before the first production deployment:

- `ENVIRONMENT=production`
- `SECRET_KEY` — a unique random value with at least 32 characters
- `DATABASE_URL` — a PostgreSQL connection string using the provider's pooled endpoint when available, in the `postgresql+psycopg://...` format
- `PLATFORM_ADMIN_NAME`, `PLATFORM_ADMIN_USERNAME`, `PLATFORM_ADMIN_EMAIL`, and `PLATFORM_ADMIN_PASSWORD` — use a private, unique email and password of at least 12 characters
- `CORS_ORIGINS=https://www.infotime.space`
- `DB_POOL_SIZE=2`, `DB_MAX_OVERFLOW=2`, and `DB_POOL_TIMEOUT=30` to limit per-function database connections

Leave the optional `BOOTSTRAP_*` values blank unless the deployment should begin with a specific business workspace. Do not use SQLite or development demo accounts on Vercel. Attach the custom domain only after the production deployment and `/api/health` are confirmed; follow the exact DNS records Vercel shows and retain unrelated mail and verification records.

Compose defaults to two Uvicorn workers with a per-worker Postgres pool of five connections plus up to ten overflow connections. Tune `WEB_CONCURRENCY`, `DB_POOL_SIZE`, and `DB_MAX_OVERFLOW` to your server's memory and database connection limits before scaling replicas. The dashboard uses database aggregates and indexed date scopes; run load tests with representative plant data before increasing traffic.

This is a pilot MVP, not a security-audited production system. Before storing sensitive factory data or relying on it for critical operations, review the known limitations below, configure HTTPS and backups, and have the deployment security reviewed. In particular, browser access tokens currently use local storage; move to a reviewed secure-cookie session design before a wider rollout.

### PostgreSQL backup and restore

Run a backup from the project directory on the Docker host and copy it to storage outside that host:

```bash
docker compose exec -T db pg_dump -U udyogos -d udyogos > udyogos-backup.sql
```

Restore into a stopped app and an empty database after confirming the backup file is correct:

```bash
docker compose stop app
docker compose exec -T db psql -U udyogos -d udyogos < udyogos-backup.sql
docker compose start app
```

Schedule backups and verify restores regularly. `docker compose down -v` removes the persistent database volume and deletes its data.

The repository does not contain a hosting account, domain, deployment credentials, or a configured Git remote. Docker Compose prepares the application and database, but a public URL is assigned by your hosting provider after deployment and DNS/HTTPS setup. The included deployment uses Docker; confirm your plan supports Docker containers and persistent PostgreSQL storage before using it.

## Run tests

From the project root:

```bash
pip install -r requirements-dev.txt
PYTHONPATH=backend pytest -q  # macOS / Linux
# Windows PowerShell: $env:PYTHONPATH = "backend"; pytest -q
```

Run the frontend checks with Node.js 20 or newer:

```bash
node --check frontend/app.js
node scripts/check_frontend.mjs
```

## Project structure

```text
udyogos_mvp/
├── backend/
│   └── app/
│       ├── config.py       # Environment configuration
│       ├── database.py     # SQLAlchemy engine and sessions
│       ├── deps.py         # Authentication and role dependencies
│       ├── main.py         # API routes and static web serving
│       ├── models.py       # Database models
│       ├── schemas.py      # Request/response validation
│       ├── security.py     # scrypt password hashing and JWT
│       └── seed.py         # Demo workspace data
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── tests/
│   └── test_api.py
├── MASTER_BUILD_PROMPT.md
├── AI_FACTORY_ASSISTANT_PROMPTS.md
├── Dockerfile
├── docker-compose.yml
└── requirements.txt
```

## Main API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/login` | Obtain access token |
| POST | `/api/auth/register` | Register a business workspace and its first owner |
| GET | `/api/auth/me` | Current user |
| GET | `/api/factory` | Current factory |
| PATCH | `/api/factory` | Update the signed-in owner's business profile |
| GET | `/api/platform/dashboard` | Platform-admin workspace and user summary |
| GET / POST | `/api/platform/factories` | List or create business workspaces (platform admin only) |
| PATCH | `/api/platform/factories/{id}` | Update or suspend/reactivate a workspace (platform admin only) |
| GET | `/api/platform/users` | List business user accounts across workspaces (platform admin only) |
| PATCH | `/api/platform/users/{id}` | Update a business account, role or sign-in access (platform admin only) |
| POST | `/api/platform/users/{id}/reset-password` | Reset a business account password (platform admin only) |
| GET / POST | `/api/users` | List users or (admin only) create a team account |
| GET | `/api/admin/users` | Admin-only list of active and inactive team accounts |
| PATCH | `/api/users/{id}` | Admin-only profile, role, and sign-in access update |
| POST | `/api/users/{id}/reset-password` | Admin-only password reset; revokes previous sessions |
| GET / POST | `/api/products` | List or add products |
| GET / POST | `/api/machines` | List or add machines |
| GET / POST / PATCH | `/api/inventory` | List, add and update stock items for the current business |
| GET / POST | `/api/inventory/movements` | List receipts/issues or record a stock movement; issues cannot create negative stock |
| GET / POST / PATCH | `/api/maintenance` | List, schedule and update maintenance work orders |
| GET | `/api/productivity` | Workspace team activity summary; operators are limited to their own row |
| GET / POST | `/api/production` | List or create production entries |
| GET / POST | `/api/quality` | List or create inspections |
| GET / POST | `/api/downtime` | List or report downtime |
| PATCH | `/api/downtime/{id}/resolve` | Resolve downtime event |
| GET / POST | `/api/tasks` | List or create actions |
| PATCH | `/api/tasks/{id}` | Update task status/priority/assignee |
| GET | `/api/dashboard` | KPIs for a date range |
| GET | `/api/insights` | Rule-based operational observations |
| GET | `/api/reports/export.csv?kind=production` | Export production, quality, downtime, tasks, inventory, maintenance or team activity as CSV |
| GET | `/docs` | Interactive API documentation |

## Known limitations and next build steps

1. **User administration:** Admin panel supports creating, editing, disabling/reactivating, and password-resetting accounts. Public registration currently does not verify email ownership or include signup rate limiting; add verified invitations/self-service recovery, account lockout and access auditing before broad public registration.
2. **Security hardening:** browser tokens are stored in localStorage for this starter. For a real deployment, move to secure HttpOnly cookies or another reviewed session design, add CSRF protection as applicable, rate limiting, account lockout, password reset, audit logs, and security testing.
3. **Database migrations:** tables are created with SQLAlchemy metadata for first boot. Add Alembic migrations before applying schema changes to an existing production database.
4. **AI integration:** current insights are rules-based. Add a secured server-side LLM provider only after agreeing on data privacy, customer consent, retention, model evaluation and human approval boundaries. Never send confidential factory data to an external model without authorization.
5. **Offline support:** this starter does not yet implement a durable offline queue or conflict resolution. Add encrypted local storage, idempotency keys, retry handling and a sync review screen before claiming offline operation.
6. **Machine/IoT integration:** downtime is manually reported. Add validated OPC-UA/MQTT/PLC connectors only with plant engineering approval and a read-only-first design.
7. **Advanced quality:** add configurable inspection plans, measurement units, tolerances, lot traceability, attachments, NCR/CAPA and approval workflow for each factory's quality system.
8. **Production analytics:** add scheduled shifts, OEE with documented formulas, scrap/rework costing, downtime reason hierarchy, and data-quality checks.
9. **Localization:** add complete Hindi and other Indian-language UI copy, translation management, timezone-aware timestamps and local number formats.
10. **Enterprise controls:** add multi-factory organisation hierarchy, paginated admin registries, granular permissions, audit trails, retention policies, backups, disaster recovery, load testing and observability. This release currently models one business workspace as one factory/site and is not load-tested for large-scale traffic.
11. **Inventory and maintenance depth:** this release tracks simple on-hand stock and preventive/corrective work orders. It does not include suppliers, purchase orders, multi-warehouse transfers, costing/valuation, spare-part reservations, maintenance templates or service-part lifecycle controls.

## Data and operational safety

- Do not use demo data as actual factory records.
- Do not connect this MVP directly to machine-control networks.
- Do not allow model-generated suggestions to modify PLC settings, bypass safety interlocks, approve product release or autonomously dispatch maintenance work.
- Human review and the factory's approved SOPs remain authoritative.
