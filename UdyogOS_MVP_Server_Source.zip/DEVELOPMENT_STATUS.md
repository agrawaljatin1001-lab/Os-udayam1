# UdyogOS development status

Last updated: 2026-11-13

## Current milestone

**Phase 1 — Pilot MVP foundation (in progress).** This source now supports multiple businesses on one website URL. A business workspace currently represents one factory/site. Business owners and their records are isolated by workspace; a separately configured platform administrator can manage business workspaces from the same website.

## Implemented

- Single-origin FastAPI website and API with PostgreSQL production configuration and SQLite development mode.
- Business self-registration creates a private workspace and its first owner account.
- Development mode seeds separate platform-admin and business-role accounts for testing both same-site interfaces.
- Sign-in by case-insensitive email or unique username.
- Platform administrator sign-in and same-site console to view, create, edit, suspend and reactivate business workspaces.
- Platform administrator global user registry to edit business user details/roles/access and reset their passwords; a business cannot lose its last active administrator.
- Business owner admin panel to update the business profile and create/edit/deactivate/reactivate users and reset passwords.
- User email, username and business contact email uniqueness across the platform.
- Server-side role checks, tenant-scoped operational queries, inactive account rejection and token revocation when access is disabled.
- Factory product and machine registers, production entries, quality inspections, downtime records, tasks, dashboard summaries, rules-based insights and CSV exports.
- Factory-scoped inventory items, opening balances, audited stock receipts/issues, stockout protection, reorder alerts and inventory CSV exports.
- Preventive/corrective maintenance work orders with assignments, due dates, completion notes and machine status synchronization.
- Team activity summary across assigned/completed tasks, production, inspections, downtime and completed maintenance. Operators only receive their own activity row.
- Startup migration helpers for legacy usernames, business contact emails, token versions, workspace activity and nullable platform-admin tenant assignment.
- Docker Compose configuration with PostgreSQL, health checks, non-root application image, environment-based platform admin bootstrap, and deployment/backup instructions.
- Frontend structural checks and API test coverage for tenant registration/isolation, admin user operations and platform workspace suspension lifecycle.

## Current limits

- One business maps to one factory/site; business groups with several factory sites are not modeled yet.
- Inventory is limited to simple stock balances and movements; supplier purchase orders, valuation/costing and multi-warehouse operations are not implemented. Maintenance lacks templates, spare-part reservations and service history beyond its work orders.
- Team activity counts recorded events; it is not an employee performance score and there is no historical task-status audit trail.
- Invitations, owner self-service password change/recovery, audit history, billing, inventory, shift handover, work orders, advanced quality workflows, and offline queue are not implemented.
- AI insights are deterministic rules, not a predictive model or conversational copilot. Voice input only uses browser dictation for a manually entered downtime note.
- There is no validated OEE calculation, scheduled notification system, or external ERP/IoT integration.
- Schema setup uses `create_all` plus limited startup SQL migrations; a complete Alembic migration history is still required for safe ongoing production upgrades.
- Browser access tokens are stored in local storage. A reviewed secure session design, rate limiting, account lockout, audit logging, and independent security review are still needed before a broad public launch.
- Public business signup does not currently verify email ownership or apply signup rate limiting; platform and business admin registries are also unpaginated.
- No representative load test has been run, so “large scale” capacity is not established.
- Hosting plan, domain, DNS, and TLS credentials are not included in this source; the deployment owner must provide them.

## Phase tracking

| Phase | Status | Notes |
|---|---|---|
| 0 — Discovery | Partial | Product assumptions and scope live in `MASTER_BUILD_PROMPT.md`; customer discovery, data dictionary and measured pilot success metrics remain open. |
| 1 — Pilot MVP | In progress | Core operational modules, basic inventory, maintenance work orders, team activity and multi-business foundation exist; audit history, complete acceptance verification, secure account recovery and full migration workflow remain. |
| 2 — Operational depth | Planned | Shift handover, advanced work-order planning, configurable inspection plans and notifications. |
| 3 — AI assistant | Planned | Evidence-grounded read-only assistant, shift summaries and reviewed voice-to-structured downtime drafts. |
| 4 — Connectivity | Planned | Offline queue, ERP/Tally exports, read-only IoT ingestion and site-level analytics. |
| 5 — Scale | Planned | Multi-site hierarchy, billing, integrations, broader localization, SSO and compliance controls. |

## Verification status

- Frontend JavaScript syntax check: passed with `node --check frontend/app.js`.
- Frontend HTML/JavaScript ID and navigation check: passed with `node scripts/check_frontend.mjs` (136 unique IDs, 12 views).
- Visual browser review: not completed; the local-file preview was blocked by the browser security policy, and no running app URL was available.
- SQLite migration SQL parity check: passed using Node's SQLite engine; confirmed legacy tenant row/FK preservation and that an unscoped platform admin can be inserted.
- Backend API tests: passed with Python 3.12 and SQLite after the inventory, maintenance and team activity extensions (18 passed); one upstream Starlette/httpx deprecation warning remains.
- Docker Compose/PostgreSQL validation: not run because the Docker CLI is unavailable here; production database startup remains unverified.
- Production deployment: not performed. A working public URL can only be issued after the owner deploys this source to a hosting plan and configures the domain and HTTPS.
