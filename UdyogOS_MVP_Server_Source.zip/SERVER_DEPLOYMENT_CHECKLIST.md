# UdyogOS server deployment checklist

## Requirements

- Docker Engine and the Docker Compose plugin
- A persistent Docker volume for PostgreSQL data
- A domain and an HTTPS reverse proxy or managed TLS certificate
- Python 3.11+ and Node.js 20+ only if running checks on the server

This app serves both the website and API from one origin. Put the container behind HTTPS. Restrict public access to the container's port so users reach it through the HTTPS proxy.

## First deployment

1. Copy the complete source folder to the server.
2. Copy `.env.production.example` to `.env` and set every required blank value. Generate different random values for `SECRET_KEY`, `POSTGRES_PASSWORD`, and the central platform administrator password. Set the administrator name, unique username, email, and `APP_PORT` if needed. The optional `BOOTSTRAP_*` fields can stay blank when businesses will register on the website.
3. Keep `.env` private. Do not include it in source control or send it in email/chat.
4. Start the app:

   ```bash
   docker compose up --build -d
   ```

5. Check the service and its database connection:

   ```bash
   docker compose ps
   curl http://127.0.0.1:8000/api/health
   ```

   The health response should include `"status":"ok"` and `"database":"connected"`.

6. Configure the HTTPS proxy and DNS, then sign in at the public domain with the platform administrator email/username and password from `.env`.
7. Create the first business in the Platform admin screen, or let business owners register directly from the public landing/login screen. Each business owner signs in on the same URL and manages their own workspace and team in its Admin panel.
8. Add products and machines for each business, and share initial/reset passwords privately.
9. Run the browser/API smoke checks, verify a database backup, and test restoring that backup to a separate empty database before recording real production data.

## Updating the app

Keep the PostgreSQL volume and `.env` while updating the source. Back up the database before updates. Then rebuild and restart:

```bash
docker compose up --build -d
```

The startup creates missing tables and indexes on a fresh database. It does not migrate changed columns in an existing database; add and apply an Alembic migration before shipping schema changes to an existing installation.

## Checks

From the source folder:

```bash
node --check frontend/app.js
node scripts/check_frontend.mjs
```

Run backend tests from PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt
$env:PYTHONPATH = "backend"
pytest -q
```

Run backend tests from Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt
PYTHONPATH=backend pytest -q
```

## Backup

Run from the project folder and copy the resulting file off the server:

```bash
docker compose exec -T db pg_dump -U udyogos -d udyogos > udyogos-backup.sql
```

Keep scheduled backups outside the host and test restores against a fresh database. Do not run `docker compose down -v` on a database with data you need; it deletes the Postgres volume.

## Current scope and operating limits

This is a multi-business pilot application. Each business currently maps to one factory/site and has isolated users, production records, inspections, downtime, tasks, assets, reports, and rules-based insights. The platform administrator and business owners use the same website URL with role-based screens. It is not a certified MES/ERP, quality-release system, safety controller, or predictive AI system. It does not yet include invitations, self-service password change, audit history, offline synchronization, inventory, multi-site management, or full Alembic migrations. The web client currently stores access tokens in local storage. Complete a security review and load test before a broad or safety-critical rollout.
