# UdyogOS — Master Product & Engineering Prompt

Copy the complete prompt below into Cursor, Claude Code, Replit Agent, Bolt, Lovable or another coding agent. For best results, attach the supplied UdyogOS MVP source project and ask the agent to extend it rather than discard the working implementation.

---

## MASTER PROMPT START

You are a principal product architect, senior full-stack engineer, industrial software specialist, UX designer and application security engineer. Build **UdyogOS**, a secure, mobile-first, multi-tenant AI-assisted factory operations platform for small and medium-sized manufacturers in India, designed to expand internationally.

Do not build a generic admin dashboard or a chatbot wrapper. Build a practical operating system that helps a factory owner and its teams record production, understand quality losses, track machine downtime, assign corrective actions and make evidence-based daily decisions.

### 1. Product vision

**Product name:** UdyogOS  
**Category:** Manufacturing operations SaaS / factory operating system  
**Tagline:** Run your factory. With clarity.  
**Initial market:** Small and medium manufacturing units in India, beginning with industrial clusters in Madhya Pradesh such as Pithampur, Indore, Dewas and Bhopal.  
**Primary devices:** Android phones, tablets and desktop web browsers.  
**Primary languages:** English and Hindi in the first release; architecture must support additional Indian languages.  
**Business model:** B2B SaaS subscription, onboarding/implementation charges and optional integrations.  
**Primary promise:** Give smaller factories a simple, affordable view of daily operations without forcing them to replace their accounting, ERP, PLC or quality systems on day one.

### 2. Core product principles

1. Solve one valuable workflow end-to-end before adding a long feature list.
2. Make recording a production or downtime event possible in seconds on a low-cost Android phone.
3. Design for noisy factory floors, gloves, low digital literacy, intermittent connectivity and mixed-language communication.
4. Make all operational numbers traceable to source records. Show filters, units, date ranges and calculation definitions.
5. The AI must explain its evidence and uncertainty. It must not invent production data, causes, machine readings or savings.
6. Human supervisors retain authority over quality release, machine safety, maintenance work and process changes.
7. Never connect the AI directly to machine controls or allow it to change PLC settings, safety interlocks or machine parameters.
8. Tenant data must be isolated at every API, query, file, export and background-job boundary.
9. Prefer integrations and incremental adoption over a risky full ERP replacement.
10. Build an accessible, fast and responsive product; do not use fake chart data or nonfunctional buttons.

### 3. Users, personas and permissions

Create tenant/workspace roles with server-enforced permissions:

- **Owner / tenant admin:** manages factory profile, locations, users, roles, products, machines, billing configuration and all reports.
- **Plant / production manager:** manages shifts, lines, production plans, tasks, downtime, reports and team assignments.
- **Quality manager / inspector:** records inspections, defect classifications, measurement results, non-conformances and corrective actions.
- **Maintenance lead / technician:** receives breakdown alerts, owns work orders, records diagnosis, parts used, repair actions and verification.
- **Shift supervisor:** records shift handover, production, quality checks, downtime and action assignments within assigned plant/line.
- **Operator:** submits production counts, machine stop/start reports and assigned task updates; cannot approve their own critical quality disposition.
- **Read-only viewer / auditor:** sees authorized dashboards, reports and audit history without editing records.

Use least-privilege permissions. Check permissions on the server for every operation. Hiding a button in the frontend is not authorization. Users can belong to more than one factory/site in later phases; every request must resolve an active tenant and site scope.

### 4. Information architecture and navigation

Create a clean web app and mobile-responsive interface with:

1. Overview
2. Production
3. Production planning and shifts
4. Quality control
5. Non-conformance and corrective actions (NCR/CAPA)
6. Machines and assets
7. Downtime and maintenance work orders
8. Inventory and material consumption (later phase)
9. Tasks and shift handover
10. Reports and analytics
11. AI Factory Copilot
12. Products, processes, lines and factory setup
13. Users, roles and audit log
14. Integrations and settings

The MVP navigation should expose only modules that work. Mark future modules as planned, not clickable fake features.

### 5. MVP scope — implement these workflows completely

#### A. Authentication and tenant onboarding

- Secure sign-in, sign-out, password reset/invitation flow and session expiry.
- Create a factory tenant with name, address/city, timezone, industry, currency, units and work week.
- Create the first owner account and optional demo workspace.
- Invite teammates by email; invite acceptance creates a user only after token verification.
- Support role and site assignment.
- Add a profile page and secure password change.
- Never ship shared demo credentials in production.

#### B. Products and process master data

- Product name, SKU, description, category, unit of measure, active state and optional drawing/document references.
- Production line, work center, process step and shift definitions.
- Machine name, asset code, line, location, manufacturer/model, installation date, maintenance interval and status.
- Avoid duplicate SKU or asset code within the same tenant unless the user explicitly confirms.
- Provide search, filters, pagination, validation and archival rather than destructive deletion when records are referenced.

#### C. Production recording

- Record date, shift, line, product, work order/lot if configured, target quantity, good quantity, rejected quantity, rework quantity, operator/supervisor and notes.
- Support partial submissions and multiple entries per shift.
- Validate non-negative counts and document whether actual output means total produced or good units.
- Show actual vs target, achievement %, output by shift, line, product and date.
- Make the formula visible: achievement = recorded output / planned target × 100. Never mix gross output and good output silently.
- Provide correction/amendment workflow with reason and audit history; do not silently overwrite past production records.

#### D. Quality control

- Create configurable inspection templates for incoming, in-process and final inspection.
- Record lot/batch, sample size, inspected quantity, accepted quantity, rejected quantity, defect code, severity, measurement name, measured value, unit, tolerance range, inspector, equipment used, time and attachment evidence.
- Validate accepted + rejected totals against inspected quantity where that model is used.
- Allow defects to be categorized and trended by product, line, shift, machine, supplier and defect code.
- Support hold / review / released dispositions only with explicit permission and audit trail.
- Never let an LLM decide whether a product is safe or compliant. Provide recommendations only; a qualified human approves disposition.

#### E. Machine downtime and maintenance

- Start a downtime event with machine, reported time, reason category, free-text notes, reporter, production line and optional assignee.
- Track open duration from server timestamps. Handle timezone display consistently.
- Record event status: open, acknowledged, in repair, awaiting parts, verification, resolved.
- Create a linked work order with owner, priority, due date, diagnosis, repair steps, parts, labour and verification checklist.
- Close downtime only after an authorized person records a resolution and confirms machine status through the approved site procedure.
- Preserve all status transitions in the audit log.
- Show downtime minutes by machine, line, reason, shift and date.
- Do not label the product predictive maintenance unless it is validated against real historical failure data.

#### F. Tasks and shift handover

- Tasks have a title, description, category, priority, owner, due date, linked machine/production/quality event, status and comments.
- Statuses: open, in progress, blocked, ready for verification, done, cancelled.
- Capture who changed the status and when.
- Shift handover captures outgoing and incoming shifts, open machine events, incomplete work, quality holds, safety notes and sign-off.
- Add notifications for assignment, overdue tasks and unresolved critical downtime; use configurable quiet hours.

#### G. Dashboard and reports

- Dashboard date filters and site/line/shift filters.
- KPIs: planned output, gross output, good output, target achievement, first-pass yield (only when inputs support it), rejection/scrap rate, rework, downtime minutes, open breakdowns, overdue tasks and maintenance backlog.
- Show numerator, denominator, unit and formula on hover or details view.
- Do not invent OEE. Only show OEE when availability, performance and quality inputs are defined and complete; show the documented formula and missing-data warning.
- Reports export to CSV and printable PDF; exports must respect the current tenant/site permissions and filters.
- Show source-data freshness and missing-data warnings.
- Make empty states useful and explain how to enter the first records.

### 6. AI Factory Copilot — staged, evidence-grounded AI

Build AI capabilities as a controlled service layer, not as arbitrary model-generated database changes.

**MVP AI capabilities:**
- Convert a spoken Hindi/English downtime report into a structured draft with machine, reason, reported time and confidence; user reviews before saving.
- Summarize the last shift using actual production, quality, downtime and task records.
- Answer read-only questions such as “Which line missed its target yesterday?” using authorized, scoped database queries.
- Explain a dashboard metric by showing the underlying calculation and source records.
- Suggest follow-up questions or investigations, with uncertainty clearly labelled.

**AI architecture:**
- Backend-only model credentials; never expose API keys in frontend code.
- Provider adapter so the application can switch between LLM providers.
- Strict JSON schemas for extracted events; validate all fields before showing a draft.
- Read-only database tools by default. Write operations require an explicit human confirmation step and use normal application APIs.
- Pass only the minimum authorized data needed for the request.
- Add prompt injection defences: factory notes, uploaded documents and user messages are untrusted data, not system instructions.
- Keep prompts, model versions, usage, errors and user feedback in controlled logs without storing secrets.
- Provide “AI-generated draft” and confidence labels. Require user review for extracted machine, date, quantity, defect and assignee fields.
- If evidence is insufficient, answer “I do not have enough recorded data” rather than guessing.
- Never claim that an AI insight is a measured saving or proven root cause unless a controlled analysis supports that claim.

**AI safety boundaries:** no PLC writes, no machine control, no bypassing lockout/tagout, no safety instruction generation as a substitute for approved SOPs, no automatic quality release, no automatic purchase order, no payroll decisions, no worker performance scoring and no employee surveillance features.

### 7. Offline-first and low-connectivity design

Phase the work carefully:
- MVP: clearly indicate connectivity and prevent duplicate submissions during slow requests.
- Next phase: encrypted local draft queue for production, quality and downtime reports.
- Use idempotency keys and server-side duplicate detection.
- Sync on reconnect with visible pending/synced/failed states.
- If a record conflicts, do not silently choose a winner. Show both versions and require authorized resolution.
- Support retry, backoff, clock skew handling and attachment upload resume.
- Do not advertise offline support until these behaviours are tested on real devices.

### 8. UX and visual design requirements

Create a professional, calm industrial SaaS interface:
- Brand: UdyogOS.
- Colour direction: deep navy, white, light grey, restrained blue accent, green for healthy states, amber for warnings and red for critical exceptions.
- Typography: legible sans-serif with strong hierarchy and high contrast.
- Desktop layout: compact left navigation, workspace selector, top bar and clear operational dashboard.
- Mobile layout: bottom navigation or collapsible navigation; large touch targets; single-column forms; quick action buttons.
- Forms should be short, grouped and usable with one hand. Use numeric keyboards for quantities.
- Use clear units (pcs, kg, litres, minutes) and Indian number formatting where appropriate.
- Every table needs loading, empty, error and pagination states.
- Every action needs saving, success and failure feedback.
- Support keyboard navigation, labels, visible focus, semantic HTML and WCAG 2.2 AA contrast targets.
- Avoid visual clutter, excessive gradients, meaningless animations, fake notifications and decorative statistics.
- Do not make critical status identifiable by colour alone; include text and icons.

### 9. Technical architecture

Use a maintainable modular monolith initially. Do not split into microservices without demonstrated scaling requirements.

Preferred stack (follow the existing repository if already selected unless there is a concrete reason to migrate):
- Frontend: React + TypeScript + Vite or Next.js; accessible component system; responsive styles; React Query/TanStack Query for server state.
- Backend: Python FastAPI with Pydantic v2.
- Database: PostgreSQL with SQLAlchemy 2 and Alembic migrations.
- Authentication: secure sessions or short-lived JWT access tokens with a reviewed refresh/session design; Argon2id password hashing.
- Background jobs: a queue such as Celery/RQ only when notifications, scheduled reports or long-running tasks require it.
- File storage: private object storage with signed URLs and malware scanning for uploads.
- Observability: structured logs, error monitoring, health checks, metrics and traces.
- Testing: pytest for backend, frontend component tests, Playwright end-to-end tests.
- Deployment: Docker, managed PostgreSQL, TLS reverse proxy, CI/CD and separate development/staging/production environments.

If using the supplied UdyogOS MVP, keep its FastAPI + SQLAlchemy API and responsive frontend unless there is a measured reason to replace them. Add changes incrementally and provide database migrations.

### 10. Core data model

Design normalized relational tables including:
- tenants / factories / sites
- users / roles / permissions / invitations / sessions
- products / product revisions / units
- production_lines / work_centres / shifts / processes
- machines / assets / maintenance plans
- production_orders / production_entries / lots / material_consumption
- inspection_templates / inspections / measurement_results / defects / non_conformances
- downtime_events / work_orders / work_order_updates / spare_parts
- tasks / comments / shift_handovers / attachments
- notifications / notification_preferences
- audit_events
- AI_requests / AI_feedback / prompt_versions (privacy-aware and retention-controlled)

Every tenant-owned record must include tenant_id and, where appropriate, site_id. Use foreign keys, indexes, uniqueness constraints, soft archive where required and database transactions for multi-record changes. Avoid unbounded JSON blobs for core business entities.

### 11. Security, privacy and compliance requirements

- Enforce tenant isolation server-side in every query, export and file access.
- Passwords hashed with Argon2id; secrets stored outside source control.
- HTTPS in deployed environments; secure cookies or an explicitly reviewed token strategy.
- CSRF protection where cookie-based sessions are used.
- Rate-limit login and sensitive actions; audit login attempts and permission changes.
- Validate and sanitize all inputs; parameterized database access; output escaping; upload size/type controls.
- Apply least privilege and deny by default.
- Encrypt backups and sensitive data in transit and at rest where supported.
- Define data retention, deletion, export, backup and disaster recovery procedures.
- Avoid sending personal data, confidential drawings or production data to external AI providers without tenant authorization and contractual safeguards.
- Never expose internal stack traces or credentials to users.
- Add a security review and threat model before production use.

### 12. API quality requirements

- Version the API (`/api/v1` for a new implementation or provide a migration plan for an existing `/api`).
- Use consistent pagination, filtering, sorting and structured error shapes.
- Validate all foreign keys belong to the authenticated tenant.
- Use idempotency for event submissions and external webhook handling.
- Use transactions when a business event changes multiple records.
- Include request IDs and structured audit events.
- Document endpoints with OpenAPI descriptions and example payloads.
- Never accept tenant_id from the browser as the authority; derive tenant scope from the authenticated session and explicit membership.

### 13. Testing and acceptance criteria

The release is not done until all applicable checks pass:

**Authentication & isolation**
- Unauthenticated requests to private endpoints return 401.
- A user from Tenant A cannot read, update, export or infer Tenant B records by changing IDs, query filters or URLs.
- Roles are enforced in the API, not only in the UI.
- Disabled users cannot sign in or use active sessions.

**Production**
- Valid records save and appear in the correct dashboard date range.
- Negative quantities are rejected.
- Actual, good and rejected quantity definitions are consistent and documented.
- Corrections leave audit history.

**Quality**
- Rejected quantity cannot exceed inspected quantity where quantity accounting applies.
- Defect rates use the correct denominator.
- Quality holds and releases require proper permission and audit events.

**Downtime**
- A new event starts with an accurate server timestamp.
- Open duration changes without writing repeated fake records.
- Resolve is permission-controlled and records who resolved it and when.
- Concurrent resolve calls do not create duplicate closure events.

**Tasks and shift handover**
- Status and assignment changes are recorded with actor/time.
- Unauthorized users cannot update another person's restricted task.
- Overdue tasks are computed using the tenant timezone and current date.

**Dashboard and reports**
- KPIs match independently calculated fixture data.
- Date boundaries and timezone changes are tested.
- Exported records match filters and permission scope.
- Empty, loading and failure states are usable.

**AI**
- Prompt-injection text inside a factory note cannot override system instructions.
- The assistant cites record IDs/timestamps for operational claims.
- It refuses to guess missing data.
- It cannot execute write actions without explicit confirmation.
- It never suggests directly changing machine controls or bypassing safety procedures.

**Quality engineering**
- Automated unit, API and end-to-end tests run in CI.
- Mobile viewport checks cover common Android widths.
- Accessibility checks cover labels, focus order, semantics and contrast.
- Dependency/security scanning runs before production deployment.

### 14. Delivery approach

Work in the following phases, keeping the app runnable after every phase:

**Phase 0 — Discovery:** list assumptions, target factory segment, interview questions, data dictionary and success metrics. Do not invent customer validation.

**Phase 1 — Pilot MVP:** authentication, tenant setup, products/machines, production, quality log, downtime log, tasks, dashboard, CSV export and audit trail.

**Phase 2 — Operational depth:** shift handover, work orders, defect Pareto analysis, configurable inspection plans and notifications.

**Phase 3 — AI assistant:** voice capture drafts, grounded read-only queries, shift summaries and explanation of KPI calculations, all with human review.

**Phase 4 — Connectivity:** offline queue, integrations, ERP/Tally export, IoT read-only ingestion and site-level analytics.

**Phase 5 — Scale:** multi-site, billing, partner ecosystem, internationalization, enterprise SSO and compliance controls.

At the end of each phase, provide:
1. A summary of what was actually implemented.
2. A complete list of changed files.
3. Exact setup and run commands for Windows and macOS/Linux.
4. Database migration commands.
5. Test commands and their real results.
6. Demo credentials only for local development.
7. Known limitations and next steps.
8. No claim of production readiness unless security, load, recovery and customer acceptance tests actually passed.

### 15. Product success metrics

Track actual outcomes rather than vanity metrics:
- Weekly active factories and active roles per factory.
- Percentage of shifts with a complete production entry.
- Median time to log a downtime event.
- Time from breakdown report to acknowledgement and resolution.
- Inspection coverage and data completeness.
- Reduction in missing or late shift reports.
- Task closure rate and overdue action rate.
- Paid pilot conversion, renewal and churn.
- Measured time saved per supervisor per week.
- Customer-reported impact supported by baseline and follow-up measurement.

Do not claim rejection reduction, increased productivity or financial savings until a customer baseline and follow-up measurement support the claim.

### 16. Instructions to the coding agent

- First inspect the attached repository and report its structure. Preserve working features.
- Produce a concise implementation plan and list critical assumptions, then begin implementation without asking broad questions.
- If a requirement is too large, complete the pilot MVP path first and clearly mark deferred features.
- Write real code, not pseudocode or static mock screens.
- Connect all visible buttons, forms, filters, tables and navigation to working functionality.
- Use server-side validation and tenant-scoped queries.
- Add database migrations, tests, seed data for local demo use and complete setup documentation.
- Never hardcode API keys, passwords or production credentials.
- Do not invent integrations or claim they work until they are implemented and tested.
- Do not replace real business logic with random numbers or fake analytics.
- Verify the application can start from a clean database and that demo workflows work end-to-end.
- Where an external service requires credentials, implement a safe adapter and document exactly which environment variables are needed; keep the app functional without credentials in demo mode.
- Prefer simple, maintainable code over premature microservices.
- Deliver the full source tree and a ZIP/archive of the completed application when the environment supports file creation.

**Final instruction:** Build UdyogOS as a dependable factory operations product that a real supervisor can use during a shift. Prioritize data correctness, tenant isolation, speed of entry and operational trust over flashy AI claims.

## MASTER PROMPT END
